﻿-- =======================================================
-- RESET DATABASE (⚠ chỉ dùng khi TEST)
-- =======================================================
USE master;
GO
IF DB_ID('LiteFlowDB') IS NOT NULL
BEGIN
    ALTER DATABASE LiteFlowDB SET SINGLE_USER WITH ROLLBACK IMMEDIATE;
    DROP DATABASE LiteFlowDB;
END
GO
CREATE DATABASE LiteFlowDB;
GO
USE LiteFlowDB;
GO

-- =======================================================
-- 1. AUTHENTICATION & AUTHORIZATION
-- =======================================================
CREATE TABLE Users (
    UserID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Email NVARCHAR(320) NOT NULL UNIQUE,
    Phone NVARCHAR(32) UNIQUE,
    GoogleID NVARCHAR(200) NULL,
    PasswordHash NVARCHAR(MAX) NOT NULL,
    TwoFactorSecret NVARCHAR(200) NULL,
    DisplayName NVARCHAR(200),
    IsActive BIT DEFAULT 1,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME(),
    UpdatedAt DATETIME2 DEFAULT SYSDATETIME(),
    Meta NVARCHAR(MAX)
);

CREATE TABLE Roles (
    RoleID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Name NVARCHAR(100) UNIQUE,
    Description NVARCHAR(500)
);

CREATE TABLE UserRoles (
    UserID UNIQUEIDENTIFIER NOT NULL,
    RoleID UNIQUEIDENTIFIER NOT NULL,
    PRIMARY KEY(UserID, RoleID)
);

CREATE TABLE Sessions (
    SessionID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    UserID UNIQUEIDENTIFIER NOT NULL,
    JWT NVARCHAR(MAX),
    DeviceInfo NVARCHAR(500),
    IPAddress NVARCHAR(50),
    CreatedAt DATETIME2 DEFAULT SYSDATETIME(),
    ExpiresAt DATETIME2,
    Revoked BIT DEFAULT 0
);

CREATE TABLE AuditLogs (
    AuditID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    UserID UNIQUEIDENTIFIER NULL,
    Action NVARCHAR(200),
    ObjectType NVARCHAR(100),
    ObjectID UNIQUEIDENTIFIER NULL,
    Details NVARCHAR(MAX),
    IPAddress NVARCHAR(50),
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

-- =======================================================
-- 2. POS / SALES
-- =======================================================
CREATE TABLE Customers (
    CustomerID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Name NVARCHAR(200),
    Email NVARCHAR(320),
    Phone NVARCHAR(32),
    Address NVARCHAR(500),
    Meta NVARCHAR(MAX)
);

CREATE TABLE Promotions (
    PromoID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Code NVARCHAR(50) UNIQUE,
    Type NVARCHAR(50),
    Value DECIMAL(18,2),
    StartDate DATETIME2,
    EndDate DATETIME2,
    Conditions NVARCHAR(MAX)
);

CREATE TABLE SalesOrders (
    OrderID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    CustomerID UNIQUEIDENTIFIER NULL,
    Branch NVARCHAR(100),
    OrderDate DATETIME2 DEFAULT SYSDATETIME(),
    Status NVARCHAR(50) NOT NULL,
    TotalAmount DECIMAL(18,2),
    CreatedBy UNIQUEIDENTIFIER NOT NULL,
    PromoID UNIQUEIDENTIFIER NULL,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

CREATE TABLE SalesOrderLines (
    LineID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    OrderID UNIQUEIDENTIFIER NOT NULL,
    ProductID UNIQUEIDENTIFIER NULL,
    SKUID UNIQUEIDENTIFIER NULL,
    Quantity INT NOT NULL,
    UnitPrice DECIMAL(18,2) NOT NULL,
    Discount DECIMAL(18,2) DEFAULT 0,
    LineTotal AS (Quantity * UnitPrice - Discount) PERSISTED
);

CREATE TABLE Payments (
    PaymentID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    OrderID UNIQUEIDENTIFIER NOT NULL,
    Method NVARCHAR(50),
    Amount DECIMAL(18,2),
    PaidAt DATETIME2 DEFAULT SYSDATETIME(),
    Reference NVARCHAR(200)
);

CREATE TABLE EInvoices (
    InvoiceID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    OrderID UNIQUEIDENTIFIER NOT NULL,
    ExternalRef NVARCHAR(200),
    Status NVARCHAR(50),
    IssuedAt DATETIME2 DEFAULT SYSDATETIME()
);

-- =======================================================
-- 3. INVENTORY
-- =======================================================
CREATE TABLE Products (
    ProductID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Name NVARCHAR(200),
    Category NVARCHAR(100),
    Meta NVARCHAR(MAX)
);

CREATE TABLE SKUs (
    SKUID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    ProductID UNIQUEIDENTIFIER NOT NULL,
    Code NVARCHAR(100) UNIQUE,
    Attributes NVARCHAR(MAX),
    ExpiryDate DATE NULL
);

CREATE TABLE InventoryLocations (
    LocationID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Branch NVARCHAR(100),
    Name NVARCHAR(200),
    Type NVARCHAR(50),
    Address NVARCHAR(500)
);

CREATE TABLE StockLevels (
    SKUID UNIQUEIDENTIFIER NOT NULL,
    LocationID UNIQUEIDENTIFIER NOT NULL,
    Quantity INT DEFAULT 0,
    PRIMARY KEY(SKUID, LocationID)
);

CREATE TABLE StockMovements (
    MovementID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    SKUID UNIQUEIDENTIFIER NOT NULL,
    LocationID UNIQUEIDENTIFIER NOT NULL,
    Quantity INT,
    Type NVARCHAR(50),
    Reference NVARCHAR(200),
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

-- =======================================================
-- 4. PROCUREMENT
-- =======================================================
CREATE TABLE Suppliers (
    SupplierID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Name NVARCHAR(200),
    Contact NVARCHAR(200),
    Phone NVARCHAR(32),
    Email NVARCHAR(320),
    SLA NVARCHAR(MAX)
);

CREATE TABLE PurchaseOrders (
    POID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    SupplierID UNIQUEIDENTIFIER NOT NULL,
    Status NVARCHAR(50) NOT NULL,
    CreatedBy UNIQUEIDENTIFIER NOT NULL,
    ApprovedBy UNIQUEIDENTIFIER NULL,
    ApprovedAt DATETIME2 NULL,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

CREATE TABLE POLines (
    POLineID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    POID UNIQUEIDENTIFIER NOT NULL,
    SKUID UNIQUEIDENTIFIER NOT NULL,
    Quantity INT,
    UnitPrice DECIMAL(18,2)
);

CREATE TABLE GoodsReceipts (
    ReceiptID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    POID UNIQUEIDENTIFIER NOT NULL,
    SKUID UNIQUEIDENTIFIER NOT NULL,
    QuantityReceived INT,
    ReceivedAt DATETIME2 DEFAULT SYSDATETIME()
);

CREATE TABLE SupplierInvoices (
    InvoiceID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    SupplierID UNIQUEIDENTIFIER NOT NULL,
    POID UNIQUEIDENTIFIER NOT NULL,
    Amount DECIMAL(18,2),
    Status NVARCHAR(50),
    IssuedAt DATETIME2,
    PaidAt DATETIME2 NULL
);

-- =======================================================
-- 5. HR / PAYROLL
-- =======================================================
CREATE TABLE Employees (
    EmployeeID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    UserID UNIQUEIDENTIFIER NULL,
    FullName NVARCHAR(200),
    Position NVARCHAR(100),
    HireDate DATE,
    BaseSalary DECIMAL(18,2),
    Meta NVARCHAR(MAX)
);

CREATE TABLE Shifts (
    ShiftID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    EmployeeID UNIQUEIDENTIFIER NOT NULL,
    StartTime DATETIME2,
    EndTime DATETIME2,
    Type NVARCHAR(50)
);

CREATE TABLE Timesheets (
    TimesheetID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    EmployeeID UNIQUEIDENTIFIER NOT NULL,
    CheckIn DATETIME2,
    CheckOut DATETIME2,
    Method NVARCHAR(50)
);

CREATE TABLE LeaveRequests (
    LeaveID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    EmployeeID UNIQUEIDENTIFIER NOT NULL,
    StartDate DATE,
    EndDate DATE,
    Type NVARCHAR(50),
    Status NVARCHAR(50)
);

CREATE TABLE PayrollRuns (
    PayrollID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    PeriodStart DATE,
    PeriodEnd DATE,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

CREATE TABLE PayrollLines (
    PayrollLineID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    PayrollID UNIQUEIDENTIFIER NOT NULL,
    EmployeeID UNIQUEIDENTIFIER NOT NULL,
    BaseSalary DECIMAL(18,2),
    Allowance DECIMAL(18,2),
    Bonus DECIMAL(18,2),
    Deductions DECIMAL(18,2),
    NetPay AS (BaseSalary + Allowance + Bonus - Deductions) PERSISTED
);

CREATE TABLE SalesCommissions (
    CommissionID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    EmployeeID UNIQUEIDENTIFIER NOT NULL,
    OrderID UNIQUEIDENTIFIER NOT NULL,
    Amount DECIMAL(18,2),
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

-- =======================================================
-- 6. AI & ALERTS
-- =======================================================
CREATE TABLE Forecasts (
    ForecastID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    SKUID UNIQUEIDENTIFIER NOT NULL,
    ForecastDate DATE,
    PredictedDemand INT,
    CreatedAt DATETIME2 DEFAULT SYSDATETIME()
);

CREATE TABLE Alerts (
    AlertID UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
    Type NVARCHAR(50),
    Message NVARCHAR(MAX),
    Severity NVARCHAR(20),
    CreatedAt DATETIME2 DEFAULT SYSDATETIME(),
    Acknowledged BIT DEFAULT 0
);

-- =======================================================
-- 7. FOREIGN KEYS (gắn sau cùng)
-- =======================================================
ALTER TABLE UserRoles
  ADD CONSTRAINT FK_UserRoles_User FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE,
      CONSTRAINT FK_UserRoles_Role FOREIGN KEY (RoleID) REFERENCES Roles(RoleID) ON DELETE CASCADE;

ALTER TABLE Sessions
  ADD CONSTRAINT FK_Sessions_User FOREIGN KEY (UserID) REFERENCES Users(UserID) ON DELETE CASCADE;

ALTER TABLE AuditLogs
  ADD CONSTRAINT FK_AuditLogs_User FOREIGN KEY (UserID) REFERENCES Users(UserID);

ALTER TABLE SalesOrders
  ADD CONSTRAINT FK_SalesOrders_Customer FOREIGN KEY (CustomerID) REFERENCES Customers(CustomerID),
      CONSTRAINT FK_SalesOrders_User FOREIGN KEY (CreatedBy) REFERENCES Users(UserID),
      CONSTRAINT FK_SalesOrders_Promo FOREIGN KEY (PromoID) REFERENCES Promotions(PromoID);

ALTER TABLE SalesOrderLines
  ADD CONSTRAINT FK_SOL_Order FOREIGN KEY (OrderID) REFERENCES SalesOrders(OrderID) ON DELETE CASCADE,
      CONSTRAINT FK_SOL_Product FOREIGN KEY (ProductID) REFERENCES Products(ProductID),
      CONSTRAINT FK_SOL_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID);

ALTER TABLE Payments
  ADD CONSTRAINT FK_Payments_Order FOREIGN KEY (OrderID) REFERENCES SalesOrders(OrderID);

ALTER TABLE EInvoices
  ADD CONSTRAINT FK_EInvoices_Order FOREIGN KEY (OrderID) REFERENCES SalesOrders(OrderID);

ALTER TABLE SKUs
  ADD CONSTRAINT FK_SKU_Product FOREIGN KEY (ProductID) REFERENCES Products(ProductID);

ALTER TABLE StockLevels
  ADD CONSTRAINT FK_StockLevels_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID),
      CONSTRAINT FK_StockLevels_Location FOREIGN KEY (LocationID) REFERENCES InventoryLocations(LocationID);

ALTER TABLE StockMovements
  ADD CONSTRAINT FK_StockMov_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID),
      CONSTRAINT FK_StockMov_Location FOREIGN KEY (LocationID) REFERENCES InventoryLocations(LocationID);

ALTER TABLE PurchaseOrders
  ADD CONSTRAINT FK_PO_Supplier FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
      CONSTRAINT FK_PO_CreatedBy FOREIGN KEY (CreatedBy) REFERENCES Users(UserID),
      CONSTRAINT FK_PO_ApprovedBy FOREIGN KEY (ApprovedBy) REFERENCES Users(UserID);

ALTER TABLE POLines
  ADD CONSTRAINT FK_POL_PO FOREIGN KEY (POID) REFERENCES PurchaseOrders(POID) ON DELETE CASCADE,
      CONSTRAINT FK_POL_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID);

ALTER TABLE GoodsReceipts
  ADD CONSTRAINT FK_GR_PO FOREIGN KEY (POID) REFERENCES PurchaseOrders(POID),
      CONSTRAINT FK_GR_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID);

ALTER TABLE SupplierInvoices
  ADD CONSTRAINT FK_SI_Supplier FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID),
      CONSTRAINT FK_SI_PO FOREIGN KEY (POID) REFERENCES PurchaseOrders(POID);

ALTER TABLE Employees
  ADD CONSTRAINT FK_Emp_User FOREIGN KEY (UserID) REFERENCES Users(UserID);

ALTER TABLE Shifts
  ADD CONSTRAINT FK_Shift_Emp FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID);

ALTER TABLE Timesheets
  ADD CONSTRAINT FK_TS_Emp FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID);

ALTER TABLE LeaveRequests
  ADD CONSTRAINT FK_LR_Emp FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID);

ALTER TABLE PayrollLines
  ADD CONSTRAINT FK_PL_Run FOREIGN KEY (PayrollID) REFERENCES PayrollRuns(PayrollID) ON DELETE CASCADE,
      CONSTRAINT FK_PL_Emp FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID);

ALTER TABLE SalesCommissions
  ADD CONSTRAINT FK_SC_Emp FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
      CONSTRAINT FK_SC_Order FOREIGN KEY (OrderID) REFERENCES SalesOrders(OrderID);

ALTER TABLE Forecasts
  ADD CONSTRAINT FK_Forecasts_SKU FOREIGN KEY (SKUID) REFERENCES SKUs(SKUID);


-- ==========================
-- Sample Data
-- ==========================
-- Users
INSERT INTO Users (Email, Phone, GoogleID, PasswordHash, TwoFactorSecret, DisplayName, IsActive, Meta)
VALUES
('owner@liteflow.vn', '0901000001', 'google-oauth2|1234567890', 'HASHED_PW', '2FA1', N'Nguyễn Văn A - Owner', 1, N'{"role":"Owner"}'),
('cashier1@liteflow.vn', '0901000002', NULL, 'HASHED_PW', NULL, N'Trần Thị B - Cashier', 1, N'{"role":"Cashier"}'),
('inventory@liteflow.vn', '0901000003', NULL, 'HASHED_PW', '2FA3', N'Lê Văn C - Inventory', 1, N'{"role":"Inventory Manager"}'),
('procurement@liteflow.vn', '0901000004', NULL, 'HASHED_PW', NULL, N'Phạm Thị D - Procurement', 1, N'{"role":"Procurement Officer"}'),
('hr@liteflow.vn', '0901000005', 'google-oauth2|987654321', 'HASHED_PW', '2FA5', N'Hoàng Văn E - HR', 1, N'{"role":"HR Officer"}'),
('employee1@liteflow.vn', '0901000006', NULL, 'HASHED_PW', NULL, N'Đỗ Thị F - Staff', 1, N'{"role":"Employee"}');

-- Roles
INSERT INTO Roles (Name, Description) VALUES
('Owner', 'System owner/manager'),
('Cashier', 'Point of Sale operator'),
('Inventory Manager', 'Manage stock and products'),
('Procurement Officer', 'Manage purchase orders and suppliers'),
('HR Officer', 'Handle HR and payroll'),
('Employee', 'General staff');

-- UserRoles
INSERT INTO UserRoles (UserID, RoleID)
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%Owner%' AND r.Name = 'Owner'
UNION ALL
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%Cashier%' AND r.Name = 'Cashier'
UNION ALL
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%Inventory%' AND r.Name = 'Inventory Manager'
UNION ALL
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%Procurement%' AND r.Name = 'Procurement Officer'
UNION ALL
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%HR%' AND r.Name = 'HR Officer'
UNION ALL
SELECT u.UserID, r.RoleID FROM Users u JOIN Roles r ON u.Meta LIKE '%Employee%' AND r.Name = 'Employee';

-- Employees
INSERT INTO Employees (UserID, FullName, Position, HireDate, BaseSalary, Meta)
SELECT UserID, DisplayName, 'Cashier', '2023-05-01', 8000000, N'{"department":"POS"}'
FROM Users WHERE Email = 'cashier1@liteflow.vn';

INSERT INTO Employees (UserID, FullName, Position, HireDate, BaseSalary, Meta)
SELECT UserID, DisplayName, 'Inventory Manager', '2022-11-15', 12000000, N'{"department":"Inventory"}'
FROM Users WHERE Email = 'inventory@liteflow.vn';

INSERT INTO Employees (UserID, FullName, Position, HireDate, BaseSalary, Meta)
SELECT UserID, DisplayName, 'HR Officer', '2021-03-10', 15000000, N'{"department":"HR"}'
FROM Users WHERE Email = 'hr@liteflow.vn';

INSERT INTO Employees (UserID, FullName, Position, HireDate, BaseSalary, Meta)
SELECT UserID, DisplayName, 'Staff', '2024-01-05', 7000000, N'{"department":"General"}'
FROM Users WHERE Email = 'employee1@liteflow.vn';

-- Shifts
INSERT INTO Shifts (EmployeeID, StartTime, EndTime, Type)
SELECT EmployeeID, '2025-09-19 08:00:00', '2025-09-19 17:00:00', 'Normal'
FROM Employees WHERE Position = 'Cashier';

INSERT INTO Shifts (EmployeeID, StartTime, EndTime, Type)
SELECT EmployeeID, '2025-09-19 09:00:00', '2025-09-19 18:00:00', 'Normal'
FROM Employees WHERE Position = 'Inventory Manager';

INSERT INTO Shifts (EmployeeID, StartTime, EndTime, Type)
SELECT EmployeeID, '2025-09-19 08:30:00', '2025-09-19 17:30:00', 'Normal'
FROM Employees WHERE Position = 'HR Officer';

INSERT INTO Shifts (EmployeeID, StartTime, EndTime, Type)
SELECT EmployeeID, '2025-09-19 14:00:00', '2025-09-19 22:00:00', 'OT'
FROM Employees WHERE Position = 'Staff';

-- Timesheets
INSERT INTO Timesheets (EmployeeID, CheckIn, CheckOut, Method)
SELECT EmployeeID, '2025-09-19 07:55:00', '2025-09-19 17:05:00', 'FaceID'
FROM Employees WHERE Position = 'Cashier';

INSERT INTO Timesheets (EmployeeID, CheckIn, CheckOut, Method)
SELECT EmployeeID, '2025-09-19 09:05:00', '2025-09-19 18:10:00', 'CardSwipe'
FROM Employees WHERE Position = 'Inventory Manager';

INSERT INTO Timesheets (EmployeeID, CheckIn, CheckOut, Method)
SELECT EmployeeID, '2025-09-19 08:20:00', '2025-09-19 17:40:00', 'MobileApp'
FROM Employees WHERE Position = 'HR Officer';

INSERT INTO Timesheets (EmployeeID, CheckIn, CheckOut, Method)
SELECT EmployeeID, '2025-09-19 14:05:00', '2025-09-19 21:50:00', 'CardSwipe'
FROM Employees WHERE Position = 'Staff';

-- LeaveRequests
INSERT INTO LeaveRequests (EmployeeID, StartDate, EndDate, Type, Status)
SELECT EmployeeID, '2025-09-20', '2025-09-21', 'Annual Leave', 'Approved'
FROM Employees WHERE Position = 'Cashier';

INSERT INTO LeaveRequests (EmployeeID, StartDate, EndDate, Type, Status)
SELECT EmployeeID, '2025-09-25', '2025-09-25', 'Sick Leave', 'Pending'
FROM Employees WHERE Position = 'Staff';

/* =======================================================
   ADMIN SEED: admin@liteflow.com / 1  (BCrypt, all roles)
   ======================================================= */

-- 1) Đảm bảo có đầy đủ các quyền (nếu bạn đã insert ở trên thì các IF NOT EXISTS sẽ bỏ qua)
IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'Owner')
    INSERT INTO Roles (Name, Description) VALUES (N'Owner', N'System owner/manager');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'Cashier')
    INSERT INTO Roles (Name, Description) VALUES (N'Cashier', N'Point of Sale operator');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'Inventory Manager')
    INSERT INTO Roles (Name, Description) VALUES (N'Inventory Manager', N'Manage stock and products');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'Procurement Officer')
    INSERT INTO Roles (Name, Description) VALUES (N'Procurement Officer', N'Manage purchase orders and suppliers');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'HR Officer')
    INSERT INTO Roles (Name, Description) VALUES (N'HR Officer', N'Handle HR and payroll');

IF NOT EXISTS (SELECT 1 FROM Roles WHERE Name = N'Employee')
    INSERT INTO Roles (Name, Description) VALUES (N'Employee', N'General staff');

-- 2) Tạo user admin với mật khẩu "1" đã băm BCrypt (cost=10)
--    Hash dưới đây tương thích jBCrypt/BCrypt.checkpw trong Java
DECLARE @AdminID UNIQUEIDENTIFIER = NEWID();
DECLARE @AdminEmail NVARCHAR(320) = N'admin@liteflow.com';
DECLARE @AdminHash NVARCHAR(MAX) = N'$2a$12$Dy8XsPez0lpFU1UqExF1nuK.m8C5zPYdysgxij2t.fZhx6NtR2LFS'; -- password = "1"

IF NOT EXISTS (SELECT 1 FROM Users WHERE LOWER(Email) = LOWER(@AdminEmail))
BEGIN
    INSERT INTO Users (UserID, Email, Phone, GoogleID, PasswordHash, TwoFactorSecret, DisplayName, IsActive, Meta)
    VALUES (@AdminID, @AdminEmail, N'0901000000', NULL, @AdminHash, NULL, N'LiteFlow Admin', 1, N'{"role":"Owner"}');
END
ELSE
BEGIN
    -- Nếu user đã tồn tại, cập nhật lại hash/mở khoá
    SELECT @AdminID = UserID FROM Users WHERE LOWER(Email) = LOWER(@AdminEmail);
    UPDATE Users
      SET PasswordHash = @AdminHash,
          IsActive = 1,
          DisplayName = N'LiteFlow Admin'
      WHERE UserID = @AdminID;
END

-- 3) Gán TẤT CẢ quyền hiện có cho admin (tránh trùng bằng NOT EXISTS)
INSERT INTO UserRoles (UserID, RoleID)
SELECT @AdminID, r.RoleID
FROM Roles r
WHERE NOT EXISTS (
    SELECT 1 FROM UserRoles ur WHERE ur.UserID = @AdminID AND ur.RoleID = r.RoleID
);
