package com.liteflow.controller;

import com.liteflow.model.hr.Timesheet;
import com.liteflow.service.TimesheetService;

import jakarta.servlet.*;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.List;
import java.util.UUID;

public class TimesheetController extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String empIdStr = req.getParameter("empId");
        String action = req.getParameter("action");

        if (empIdStr == null || empIdStr.isEmpty()) {
            req.setAttribute("error", "⚠️ EmployeeID is required");
            req.getRequestDispatcher("timesheet.jsp").forward(req, resp);
            return;
        }

        UUID empId = UUID.fromString(empIdStr);
        TimesheetService service = new TimesheetService();

        if ("checkin".equalsIgnoreCase(action)) {
            service.checkIn(empId, "Web");
        } else if ("checkout".equalsIgnoreCase(action)) {
            service.checkOut(empId);
        }

        // Load lịch sử chấm công
        List<Timesheet> records = service.getByEmployee(empId);
        req.setAttribute("records", records);

        // Forward về JSP
        RequestDispatcher rd = req.getRequestDispatcher("timesheet.jsp");
        rd.forward(req, resp);
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        doPost(req, resp);
    }
}
