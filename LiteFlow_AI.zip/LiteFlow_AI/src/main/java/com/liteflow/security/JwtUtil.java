package com.liteflow.security;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;

import java.security.Key;
import java.time.Instant;
import java.util.Date;
import java.util.Map;

/**
 * JwtUtil: Sinh & kiểm tra JWT.
 * Subject = userId (UUID string)
 * Claims thêm email, displayName, role, jti.
 */
public final class JwtUtil {
    private static final Key KEY = Keys.hmacShaKeyFor(
            "change-this-secret-key-to-32-bytes-minxxxxxxxx".getBytes()
    );

    private JwtUtil() {}

    public static String createToken(String subject, long ttlSeconds, Map<String, Object> claims) {
        Instant now = Instant.now();
        JwtBuilder b = Jwts.builder()
                .setSubject(subject) // userId
                .setIssuedAt(Date.from(now))
                .addClaims(claims)
                .signWith(KEY, SignatureAlgorithm.HS256);
        if (ttlSeconds > 0) {
            b.setExpiration(Date.from(now.plusSeconds(ttlSeconds)));
        }
        return b.compact();
    }

    public static Jws<Claims> parse(String jwt) throws JwtException {
        return Jwts.parserBuilder().setSigningKey(KEY).build().parseClaimsJws(jwt);
    }
}
