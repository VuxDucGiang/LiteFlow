package com.liteflow.security;

import com.eatthepath.otp.TimeBasedOneTimePasswordGenerator;
import org.apache.commons.codec.binary.Base32;

import javax.crypto.spec.SecretKeySpec;
import java.security.InvalidKeyException;
import java.security.Key;
import java.time.Duration;
import java.time.Instant;
import java.util.concurrent.ThreadLocalRandom;

/**
 * Utility class cho TOTP (Time-based One Time Password) – 2FA.
 * 
 * Chuẩn Google Authenticator: mã 6 số, thay đổi mỗi 30 giây.
 */
public final class TotpUtil {

    // Generator chuẩn: 30 giây / step, 6 digits (default)
    private static final TimeBasedOneTimePasswordGenerator TOTP =
            new TimeBasedOneTimePasswordGenerator(Duration.ofSeconds(30));

    private TotpUtil() {
    }

    /**
     * Sinh secret mới (Base32) để lưu trong DB và tạo QR cho user.
     * 
     * @return secret Base32 string
     */
    public static String generateSecret() {
        byte[] buffer = new byte[20]; // 160-bit secret (phù hợp Google Authenticator)
        ThreadLocalRandom.current().nextBytes(buffer);
        return new Base32().encodeToString(buffer).replace("=", ""); // loại bỏ padding
    }

    /**
     * Sinh OTP hiện tại từ secret (Base32).
     * 
     * @param base32Secret secret đã lưu
     * @return mã OTP 6 số (string)
     */
    public static String generateCurrentOtp(String base32Secret) {
        try {
            Key key = buildKeyFromBase32(base32Secret);
            int otp = TOTP.generateOneTimePassword(key, Instant.now());
            return String.format("%06d", otp);
        } catch (InvalidKeyException e) {
            throw new IllegalStateException("Secret không hợp lệ", e);
        }
    }

    /**
     * Xác thực OTP nhập vào với secret (Base32).
     * Cho phép lệch ±1 step (30 giây) để tránh sai lệch giờ.
     *
     * @param base32Secret secret gốc (Base32)
     * @param code         mã OTP user nhập
     * @return true nếu hợp lệ, false nếu sai
     */
    public static boolean verifyCode(String base32Secret, String code) {
        if (base32Secret == null || code == null) return false;

        String cleanCode = code.trim();
        if (!cleanCode.matches("\\d{6}")) {
            return false; // OTP phải là 6 chữ số
        }

        try {
            Key key = buildKeyFromBase32(base32Secret);
            for (int i = -1; i <= 1; i++) { // check trước, hiện tại, sau
                Instant time = Instant.now().plusSeconds(i * 30);
                int otp = TOTP.generateOneTimePassword(key, time);
                String candidate = String.format("%06d", otp);
                if (candidate.equals(cleanCode)) {
                    return true;
                }
            }
            return false;
        } catch (InvalidKeyException e) {
            return false;
        }
    }

    /**
     * Helper: convert Base32 string sang Key (HMAC-SHA1).
     */
    private static Key buildKeyFromBase32(String base32Secret) {
        byte[] decoded = new Base32().decode(base32Secret.toUpperCase());
        return new SecretKeySpec(decoded, "HmacSHA1");
    }
}
