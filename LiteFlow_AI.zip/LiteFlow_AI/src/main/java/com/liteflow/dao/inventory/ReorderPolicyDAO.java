/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.ReorderPolicy;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class ReorderPolicyDAO extends GenericDAO<ReorderPolicy, String> {
    public ReorderPolicyDAO() { super(ReorderPolicy.class); }

    public Optional<ReorderPolicy> findOne(String skuId, String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            var l = em.createQuery("""
                SELECT r FROM ReorderPolicy r
                 WHERE r.sku.skuid = :sid AND r.location.locationID = :lid
            """, ReorderPolicy.class).setParameter("sid", skuId).setParameter("lid", locationId)
             .setMaxResults(1).getResultList();
            return l.stream().findFirst();
        } finally { em.close(); }
    }

    public List<ReorderPolicy> findByLocation(String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT r FROM ReorderPolicy r WHERE r.location.locationID = :lid", ReorderPolicy.class)
                    .setParameter("lid", locationId).getResultList();
        } finally { em.close(); }
    }
}