/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.InventoryLocation;
import jakarta.persistence.EntityManager;
import java.util.List;

public class InventoryLocationDAO extends GenericDAO<InventoryLocation, String> {
    public InventoryLocationDAO() { super(InventoryLocation.class); }

    public List<InventoryLocation> findByBranch(String branch) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT l FROM InventoryLocation l WHERE l.branch = :b", InventoryLocation.class)
                    .setParameter("b", branch).getResultList();
        } finally { em.close(); }
    }

    public List<InventoryLocation> findByBranchAndType(String branch, String type) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT l FROM InventoryLocation l WHERE l.branch = :b AND l.type = :t", InventoryLocation.class)
                    .setParameter("b", branch).setParameter("t", type).getResultList();
        } finally { em.close(); }
    }
}
