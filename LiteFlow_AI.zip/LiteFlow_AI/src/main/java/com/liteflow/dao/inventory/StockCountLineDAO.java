/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockCountLine;
import jakarta.persistence.EntityManager;
import java.util.List;

public class StockCountLineDAO extends GenericDAO<StockCountLine, String> {
    public StockCountLineDAO() { super(StockCountLine.class); }

    public List<StockCountLine> findByCount(String countId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT l FROM StockCountLine l WHERE l.count.countID = :cid", StockCountLine.class)
                    .setParameter("cid", countId).getResultList();
        } finally { em.close(); }
    }
}
