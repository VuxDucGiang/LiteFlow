/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.Product;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class ProductDAO extends GenericDAO<Product, String> {
    public ProductDAO() { super(Product.class); }

    public Optional<Product> findByProductCode(String code) {
        if (code == null || code.isBlank()) return Optional.empty();
        EntityManager em = emf.createEntityManager();
        try {
            var list = em.createQuery("SELECT p FROM Product p WHERE p.productCode = :c", Product.class)
                    .setParameter("c", code).setMaxResults(1).getResultList();
            return list.stream().findFirst();
        } finally { em.close(); }
    }

    public List<Product> searchByNameLike(String q, int limit) {
        if (q == null || q.isBlank()) return List.of();
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT p FROM Product p WHERE LOWER(p.name) LIKE :q ORDER BY p.name", Product.class)
                    .setParameter("q", "%" + q.toLowerCase().trim() + "%")
                    .setMaxResults(Math.max(1, limit))
                    .getResultList();
        } finally { em.close(); }
    }
}
