/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockAdjustmentLine;
import jakarta.persistence.EntityManager;
import java.util.List;

public class StockAdjustmentLineDAO extends GenericDAO<StockAdjustmentLine, String> {
    public StockAdjustmentLineDAO() { super(StockAdjustmentLine.class); }

    public List<StockAdjustmentLine> findByAdjustment(String adjustmentId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT l FROM StockAdjustmentLine l
                 WHERE l.adjustment.adjustmentID = :aid
            """, StockAdjustmentLine.class).setParameter("aid", adjustmentId).getResultList();
        } finally { em.close(); }
    }
}
