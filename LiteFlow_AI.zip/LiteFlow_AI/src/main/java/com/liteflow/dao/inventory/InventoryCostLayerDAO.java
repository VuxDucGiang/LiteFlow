/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.InventoryCostLayer;
import jakarta.persistence.EntityManager;
import java.util.List;

public class InventoryCostLayerDAO extends GenericDAO<InventoryCostLayer, String> {
    public InventoryCostLayerDAO() { super(InventoryCostLayer.class); }

    public List<InventoryCostLayer> findFIFOAvailable(String skuId, String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT c FROM InventoryCostLayer c
                 WHERE c.sku.skuid = :sid AND c.location.locationID = :lid AND c.qtyRemaining > 0
                 ORDER BY c.createdAt ASC
            """, InventoryCostLayer.class)
            .setParameter("sid", skuId).setParameter("lid", locationId).getResultList();
        } finally { em.close(); }
    }
}
