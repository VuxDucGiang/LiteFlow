/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockLevel;
import com.liteflow.model.inventory.StockLevelPK;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class StockLevelDAO extends GenericDAO<StockLevel, StockLevelPK> {
    public StockLevelDAO() { super(StockLevel.class); }

    public Optional<StockLevel> findOne(String skuId, String locationId) {
        return Optional.ofNullable(findById(new StockLevelPK(skuId, locationId)));
    }

    public List<StockLevel> findByLocation(String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT s FROM StockLevel s WHERE s.stockLevelPK.locationID = :lid", StockLevel.class)
                    .setParameter("lid", locationId).getResultList();
        } finally { em.close(); }
    }
}
