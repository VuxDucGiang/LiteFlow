/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockMovement;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;

public class StockMovementDAO extends GenericDAO<StockMovement, String> {
    public StockMovementDAO() { super(StockMovement.class); }

    public List<StockMovement> findByRef(String refType, String refId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT m FROM StockMovement m
                 WHERE m.refType = :rt AND m.refID = :rid
                 ORDER BY m.createdAt ASC
            """, StockMovement.class)
            .setParameter("rt", refType).setParameter("rid", refId).getResultList();
        } finally { em.close(); }
    }

    public List<StockMovement> findBySkuInRange(String skuId, Date from, Date to, int page, int size) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT m FROM StockMovement m
                 WHERE m.sku.skuid = :sid AND m.createdAt BETWEEN :f AND :t
                 ORDER BY m.createdAt ASC
            """, StockMovement.class)
            .setParameter("sid", skuId).setParameter("f", from).setParameter("t", to)
            .setFirstResult(Math.max(0,(page-1)*size)).setMaxResults(Math.max(1,size))
            .getResultList();
        } finally { em.close(); }
    }

    public long countBySkuInRange(String skuId, Date from, Date to) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT COUNT(m) FROM StockMovement m
                 WHERE m.sku.skuid = :sid AND m.createdAt BETWEEN :f AND :t
            """, Long.class)
            .setParameter("sid", skuId).setParameter("f", from).setParameter("t", to)
            .getSingleResult();
        } finally { em.close(); }
    }
}
