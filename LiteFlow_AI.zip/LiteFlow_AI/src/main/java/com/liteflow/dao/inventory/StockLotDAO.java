/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockLot;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;

public class StockLotDAO extends GenericDAO<StockLot, String> {
    public StockLotDAO() { super(StockLot.class); }

    public List<StockLot> findLotsFEFO(String skuId, String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT l FROM StockLot l
                 WHERE l.sku.skuid = :sid AND l.location.locationID = :lid AND l.qtyOnHand > 0
                 ORDER BY l.expiryDate ASC NULLS LAST, l.receivedAt ASC
            """, StockLot.class)
            .setParameter("sid", skuId).setParameter("lid", locationId).getResultList();
        } finally { em.close(); }
    }

    public List<StockLot> findExpiringBefore(String locationId, Date before) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT l FROM StockLot l
                 WHERE l.location.locationID = :lid AND l.expiryDate IS NOT NULL AND l.expiryDate < :ts AND l.qtyOnHand > 0
                 ORDER BY l.expiryDate ASC
            """, StockLot.class)
            .setParameter("lid", locationId).setParameter("ts", before).getResultList();
        } finally { em.close(); }
    }
}
