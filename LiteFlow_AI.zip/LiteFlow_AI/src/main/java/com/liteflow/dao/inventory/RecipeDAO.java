/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.Recipe;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class RecipeDAO extends GenericDAO<Recipe, String> {
    public RecipeDAO() { super(Recipe.class); }

    public Optional<Recipe> findActiveByProduct(String productId) {
        EntityManager em = emf.createEntityManager();
        try {
            var l = em.createQuery("""
                SELECT r FROM Recipe r
                 WHERE r.product.productID = :pid AND r.isActive = true
                 ORDER BY r.version DESC
            """, Recipe.class).setParameter("pid", productId)
             .setMaxResults(1).getResultList();
            return l.stream().findFirst();
        } finally { em.close(); }
    }

    public List<Recipe> findByProduct(String productId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT r FROM Recipe r WHERE r.product.productID = :pid", Recipe.class)
                     .setParameter("pid", productId).getResultList();
        } finally { em.close(); }
    }
}
