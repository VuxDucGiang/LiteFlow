/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.Category;
import jakarta.persistence.EntityManager;
import java.util.List;

public class CategoryDAO extends GenericDAO<Category, String> {
    public CategoryDAO() { super(Category.class); }

    public List<Category> findChildren(String parentId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT c FROM Category c WHERE c.parent.categoryID = :pid", Category.class)
                    .setParameter("pid", parentId).getResultList();
        } finally { em.close(); }
    }
}
