/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao;


import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;

public class DBTest {
    public static void main(String[] args) {
        try {
            EntityManagerFactory emf = Persistence.createEntityManagerFactory("LiteFlowPU");
            EntityManager em = emf.createEntityManager();

            em.getTransaction().begin();
            // Thử query dữ liệu từ 1 bảng, ví dụ bảng User
            Object result = em.createQuery("SELECT u FROM User u").setMaxResults(1).getSingleResult();
            em.getTransaction().commit();

            System.out.println("✅ Kết nối thành công, có dữ liệu: " + result);

            em.close();
            emf.close();
        } catch (Exception e) {
            System.err.println("❌ Lỗi khi kết nối DB: " + e.getMessage());
            e.printStackTrace();
        }
    }
}