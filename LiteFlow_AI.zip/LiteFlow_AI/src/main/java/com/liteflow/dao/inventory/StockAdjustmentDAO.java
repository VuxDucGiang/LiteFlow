/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockAdjustment;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;

public class StockAdjustmentDAO extends GenericDAO<StockAdjustment, String> {
    public StockAdjustmentDAO() { super(StockAdjustment.class); }

    public List<StockAdjustment> findByLocationRange(String locationId, Date from, Date to) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT a FROM StockAdjustment a
                 WHERE a.location.locationID = :lid AND a.createdAt BETWEEN :f AND :t
                 ORDER BY a.createdAt DESC
            """, StockAdjustment.class)
            .setParameter("lid", locationId).setParameter("f", from).setParameter("t", to)
            .getResultList();
        } finally { em.close(); }
    }

    public List<StockAdjustment> findByReason(String locationId, String reason) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT a FROM StockAdjustment a
                 WHERE a.location.locationID = :lid AND a.reason = :r
                 ORDER BY a.createdAt DESC
            """, StockAdjustment.class)
            .setParameter("lid", locationId).setParameter("r", reason)
            .getResultList();
        } finally { em.close(); }
    }
}
