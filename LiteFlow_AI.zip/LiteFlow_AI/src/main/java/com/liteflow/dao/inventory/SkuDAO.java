/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.SKU;
import jakarta.persistence.EntityManager;
import java.util.List;
import java.util.Optional;

public class SkuDAO extends GenericDAO<SKU, String> {
    public SkuDAO() { super(SKU.class); }

    public Optional<SKU> findByCode(String code) {
        if (code == null || code.isBlank()) return Optional.empty();
        EntityManager em = emf.createEntityManager();
        try {
            var l = em.createQuery("SELECT s FROM SKU s WHERE s.code = :c", SKU.class)
                    .setParameter("c", code).setMaxResults(1).getResultList();
            return l.stream().findFirst();
        } finally { em.close(); }
    }

    public Optional<SKU> findByBarcode(String barcode) {
        if (barcode == null || barcode.isBlank()) return Optional.empty();
        EntityManager em = emf.createEntityManager();
        try {
            var l = em.createQuery("SELECT s FROM SKU s WHERE s.barcode = :b", SKU.class)
                    .setParameter("b", barcode).setMaxResults(1).getResultList();
            return l.stream().findFirst();
        } finally { em.close(); }
    }

    public List<SKU> findByProductId(String productId) {
        if (productId == null || productId.isBlank()) return List.of();
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT s FROM SKU s WHERE s.product.productID = :pid", SKU.class)
                    .setParameter("pid", productId).getResultList();
        } finally { em.close(); }
    }
}