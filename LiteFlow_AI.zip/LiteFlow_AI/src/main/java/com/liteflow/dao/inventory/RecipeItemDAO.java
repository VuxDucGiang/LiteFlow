/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.RecipeItem;
import jakarta.persistence.EntityManager;
import java.util.List;

public class RecipeItemDAO extends GenericDAO<RecipeItem, String> {
    public RecipeItemDAO() { super(RecipeItem.class); }

    public List<RecipeItem> findByRecipe(String recipeId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("SELECT i FROM RecipeItem i WHERE i.recipe.recipeID = :rid", RecipeItem.class)
                    .setParameter("rid", recipeId).getResultList();
        } finally { em.close(); }
    }
}
