/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.dao.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.inventory.StockCount;
import jakarta.persistence.EntityManager;
import java.util.Date;
import java.util.List;

public class StockCountDAO extends GenericDAO<StockCount, String> {
    public StockCountDAO() { super(StockCount.class); }

    public List<StockCount> findOpenByLocation(String locationId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT c FROM StockCount c
                 WHERE c.location.locationID = :lid AND c.status IN ('DRAFT','COUNTED')
                 ORDER BY c.countDate DESC
            """, StockCount.class).setParameter("lid", locationId).getResultList();
        } finally { em.close(); }
    }

    public List<StockCount> findByLocationRange(String locationId, Date from, Date to) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery("""
                SELECT c FROM StockCount c
                 WHERE c.location.locationID = :lid AND c.countDate BETWEEN :f AND :t
                 ORDER BY c.countDate DESC
            """, StockCount.class)
            .setParameter("lid", locationId).setParameter("f", from).setParameter("t", to)
            .getResultList();
        } finally { em.close(); }
    }
}
