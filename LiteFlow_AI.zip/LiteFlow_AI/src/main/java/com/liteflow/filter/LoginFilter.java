package com.liteflow.filter;

import com.liteflow.model.auth.User;
import com.liteflow.security.JwtUtil;
import com.liteflow.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.UUID;

/**
 * LoginFilter:
 *  - Khi BẬT: nếu đã login thì chặn truy cập /login, redirect sang /dashboard.
 *  - Khi TẮT: luôn cho qua /login (không redirect).
 *
 * Bật/tắt bằng:
 *   - ENV: LITEFLOW_LOGINFILTER_ENABLED=true|false
 *   - hoặc VM option: -DLITEFLOW_LOGINFILTER_ENABLED=true|false
 */
@WebFilter(urlPatterns = {"/login"})
public class LoginFilter implements Filter {

    // Mặc định bật (true). Đổi bằng ENV/VM option như trên.
    private static volatile boolean LOGIN_FILTER_ENABLED = false;

    private final UserService userService = new UserService();

    @Override
    public void init(FilterConfig filterConfig) {
        try {
            String v = System.getenv("LITEFLOW_LOGINFILTER_ENABLED");
            if (v == null) v = System.getProperty("LITEFLOW_LOGINFILTER_ENABLED");
            if (v != null) LOGIN_FILTER_ENABLED = Boolean.parseBoolean(v);
        } catch (Exception ignore) {}
        System.out.println("[LoginFilter] LOGIN_FILTER_ENABLED = " + LOGIN_FILTER_ENABLED);
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        if (!LOGIN_FILTER_ENABLED) {
            // TẮT filter: luôn cho vào trang /login
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        // 1) Ưu tiên lấy user từ session
        User u = (session != null) ? (User) session.getAttribute("UserLogin") : null;

        // 2) Fallback: nếu chưa có trong session, thử JWT cookie (nếu bạn dùng SSO/JWT)
        if (u == null) {
            String jwt = null;
            Cookie[] cookies = req.getCookies();
            if (cookies != null) {
                for (Cookie c : cookies) {
                    if ("LITEFLOW_TOKEN".equals(c.getName())) {
                        jwt = c.getValue();
                        break;
                    }
                }
            }
            if (jwt != null && !jwt.isBlank()) {
                try {
                    Jws<Claims> jws = JwtUtil.parse(jwt);
                    String sub = jws.getBody().getSubject();
                    try {
                        u = userService.findById(UUID.fromString(sub));
                    } catch (IllegalArgumentException e) {
                        u = userService.findByEmail(sub);
                    }
                } catch (JwtException e) {
                    // JWT hỏng thì bỏ qua, cho người dùng vào trang login bình thường
                }
            }
        }

        // 3) Nếu đã đăng nhập -> không cho vào /login nữa, chuyển thẳng /dashboard
        if (u != null) {
            res.sendRedirect(req.getContextPath() + "/dashboard");
            return;
        }

        // 4) Chưa đăng nhập -> cho hiển thị trang /login
        chain.doFilter(request, response);
    }
}
