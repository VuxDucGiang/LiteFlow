package com.liteflow.filter;

import com.liteflow.model.auth.User;
import com.liteflow.security.JwtUtil;
import com.liteflow.service.AuditService;
import com.liteflow.service.UserService;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.*;
import java.io.IOException;
import java.util.*;

@WebFilter("/*")
public class AuthenticationFilter implements Filter {

    // ====== Công tắc nhanh ======
    // false: TẮT auth hoàn toàn (bypass)
    // true : BẬT auth + RBAC như bình thường
    private static volatile boolean AUTH_ENABLED = false;

    private final AuditService auditService = new AuditService();
    private final UserService userService = new UserService();

    private static final Map<String, Set<String>> ROLE_FUNCTIONS = new HashMap<>();

    static {
        ROLE_FUNCTIONS.put("Cashier", Set.of("/pos", "/sales", "/cart", "/checkout"));
        ROLE_FUNCTIONS.put("Inventory Manager", Set.of("/inventory", "/products", "/stock", "/purchaseOrders"));
        ROLE_FUNCTIONS.put("Procurement Officer", Set.of("/purchaseOrders", "/suppliers", "/invoices"));
        ROLE_FUNCTIONS.put("HR Officer", Set.of("/employees", "/payroll", "/timesheets", "/leaveRequests"));
        ROLE_FUNCTIONS.put("Employee", Set.of("/user/profile", "/user/timesheet", "/user/payroll"));
    }

    @Override
    public void init(FilterConfig filterConfig) {
        // Cho phép bật/tắt qua ENV/VM option (ưu tiên ENV)
        // Ví dụ: export LITEFLOW_AUTH_ENABLED=true  (Linux/Mac)
        //        setx LITEFLOW_AUTH_ENABLED true    (Windows, cần mở shell mới)
        // Hoặc VM option khi start Tomcat: -DLITEFLOW_AUTH_ENABLED=true
        try {
            String env = System.getenv("LITEFLOW_AUTH_ENABLED");
            if (env == null) env = System.getProperty("LITEFLOW_AUTH_ENABLED");
            if (env != null) AUTH_ENABLED = Boolean.parseBoolean(env);
        } catch (Exception ignore) {}
        System.out.println("[AuthenticationFilter] AUTH_ENABLED = " + AUTH_ENABLED);
    }

    private boolean isStaticResource(String path) {
        return path.startsWith("/css/") || path.startsWith("/js/") || path.startsWith("/images/") || path.startsWith("/img/")
            || path.endsWith(".css") || path.endsWith(".js")
            || path.endsWith(".jpg") || path.endsWith(".jpeg") || path.endsWith(".png") || path.endsWith(".gif") || path.endsWith(".svg") || path.endsWith(".ico")
            || path.endsWith(".woff") || path.endsWith(".woff2") || path.endsWith(".ttf") || path.endsWith(".map");
    }

    private boolean isPublicPage(String path) {
        return path.equals("/login")
            || path.equals("/register")
            || path.equals("/logout")
            || path.equals("/auth/google")
            || path.equals("/oauth2callback")   // ✅ callback đúng cho Google
            || path.equals("/auth/callback")    // nếu app bạn còn route này thì giữ lại
            || path.equals("/health")
            || path.equals("/accessDenied.jsp")
            || path.equals("/auth/login.jsp")   // tuỳ app có cho vào thẳng JSP không
            || path.equals("/login.jsp")
            || path.equals("/signup.jsp")
            || path.startsWith("/public/")
            || path.startsWith("/api/public/");
    }

    private boolean isAuthorized(String role, String path) {
        if (role == null) return false;
        if ("Owner".equalsIgnoreCase(role)) return true; // Owner full quyền
        Set<String> funcs = ROLE_FUNCTIONS.getOrDefault(role, Collections.emptySet());
        return funcs.stream().anyMatch(path::startsWith);
    }

    private String getPath(HttpServletRequest req) {
        // Ổn định hơn getServletPath trong một số cấu hình
        String ctx = req.getContextPath();
        String uri = req.getRequestURI();
        return (ctx != null && !ctx.isEmpty()) ? uri.substring(ctx.length()) : uri;
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        // ====== BYPASS TOÀN BỘ KHI AUTH_ENABLED = FALSE ======
        if (!AUTH_ENABLED) {
            chain.doFilter(request, response);
            return;
        }

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        HttpSession session = req.getSession(false);

        String path = getPath(req);

        // Bỏ qua file tĩnh + trang public
        if (isStaticResource(path) || isPublicPage(path)) {
            chain.doFilter(request, response);
            return;
        }

        User user = null;

        // Ưu tiên lấy từ JWT cookie
        String jwt = null;
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("LITEFLOW_TOKEN".equals(c.getName())) {
                    jwt = c.getValue();
                    break;
                }
            }
        }

        if (jwt != null && !jwt.isBlank()) {
            try {
                Jws<Claims> jws = JwtUtil.parse(jwt);
                Claims claims = jws.getBody();
                String subject = claims.getSubject();
                try {
                    user = userService.findById(UUID.fromString(subject));
                } catch (IllegalArgumentException e) {
                    user = userService.findByEmail(subject);
                }
            } catch (JwtException e) {
                System.err.println("⚠ JWT parse error: " + e.getMessage());
                auditService.log(null,
                        AuditService.AuditAction.LOGIN_FAIL,
                        AuditService.ObjectType.USER,
                        null,
                        "JWT parse error: " + e.getMessage(),
                        req.getRemoteAddr());
            }
        }

        // Fallback: lấy từ session
        if (user == null && session != null) {
            Object obj = session.getAttribute("UserLogin");
            if (obj instanceof User) user = (User) obj;
        }

        // Nếu chưa login → về trang login
        if (user == null) {
            res.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        // Check quyền
        String role = user.getPrimaryRoleName();
        if (isAuthorized(role, path)) {
            chain.doFilter(request, response);
        } else {
            auditService.log(
                    user,
                    AuditService.AuditAction.ACCESS_DENIED,
                    AuditService.ObjectType.OTHER,
                    user.getUserID() != null ? user.getUserID().toString() : null,
                    "Access denied vào path: " + path,
                    req.getRemoteAddr()
            );
            res.sendRedirect(req.getContextPath() + "/accessDenied.jsp");
        }
    }
}
