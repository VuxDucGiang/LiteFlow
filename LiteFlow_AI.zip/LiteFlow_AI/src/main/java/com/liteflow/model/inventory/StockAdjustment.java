/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.model.auth.User;
import jakarta.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "StockAdjustments")
public class StockAdjustment implements Serializable {
    @Id
    @Column(name = "AdjustmentID", nullable = false, updatable = false, length = 36)
    private String adjustmentID;

    @ManyToOne(optional = false) @JoinColumn(name = "LocationID", nullable = false)
    private InventoryLocation location;

    @Column(name = "Reason", nullable = false, length = 100)
    private String reason; // SCRAP / RETURN_IN / RETURN_OUT / WRITE_OFF

    @Column(name = "Note", length = 500)
    private String note;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedAt")
    private Date createdAt = new Date();

    @ManyToOne @JoinColumn(name = "CreatedBy")
    private User createdBy;

    @OneToMany(mappedBy = "adjustment", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<StockAdjustmentLine> lines = new ArrayList<>();

    public String getAdjustmentID() {
        return adjustmentID;
    }

    public void setAdjustmentID(String adjustmentID) {
        this.adjustmentID = adjustmentID;
    }

    public InventoryLocation getLocation() {
        return location;
    }

    public void setLocation(InventoryLocation location) {
        this.location = location;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public List<StockAdjustmentLine> getLines() {
        return lines;
    }

    public void setLines(List<StockAdjustmentLine> lines) {
        this.lines = lines;
    }

    @Override
    public String toString() {
        return "StockAdjustment{" + "adjustmentID=" + adjustmentID + ", location=" + location + ", reason=" + reason + ", note=" + note + ", createdAt=" + createdAt + ", createdBy=" + createdBy + ", lines=" + lines + '}';
    }
    
}

