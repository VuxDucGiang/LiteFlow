package com.liteflow.model.hr;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.UUID;

@Entity
@Table(name = "Timesheets")
@NamedQueries({
    @NamedQuery(name = "Timesheet.findAll", query = "SELECT t FROM Timesheet t"),
    @NamedQuery(name = "Timesheet.findByTimesheetID", query = "SELECT t FROM Timesheet t WHERE t.timesheetID = :timesheetID"),
    @NamedQuery(name = "Timesheet.findByCheckIn", query = "SELECT t FROM Timesheet t WHERE t.checkIn = :checkIn"),
    @NamedQuery(name = "Timesheet.findByCheckOut", query = "SELECT t FROM Timesheet t WHERE t.checkOut = :checkOut"),
    @NamedQuery(name = "Timesheet.findByMethod", query = "SELECT t FROM Timesheet t WHERE t.method = :method")
})
public class Timesheet implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "TimesheetID", columnDefinition = "uniqueidentifier")
    private UUID timesheetID;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CheckIn")
    private Date checkIn;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CheckOut")
    private Date checkOut;

    @Column(name = "Method", length = 50)
    private String method;

    @JoinColumn(name = "EmployeeID", referencedColumnName = "EmployeeID")
    @ManyToOne
    private Employee employeeID;

    public Timesheet() {
    }

    public Timesheet(UUID timesheetID) {
        this.timesheetID = timesheetID;
    }

    public UUID getTimesheetID() {
        return timesheetID;
    }

    public void setTimesheetID(UUID timesheetID) {
        this.timesheetID = timesheetID;
    }

    public Date getCheckIn() {
        return checkIn;
    }

    public void setCheckIn(Date checkIn) {
        this.checkIn = checkIn;
    }

    public Date getCheckOut() {
        return checkOut;
    }

    public void setCheckOut(Date checkOut) {
        this.checkOut = checkOut;
    }

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    public Employee getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Employee employeeID) {
        this.employeeID = employeeID;
    }

    @Override
    public int hashCode() {
        return (timesheetID != null ? timesheetID.hashCode() : 0);
    }

    @Override
    public boolean equals(Object obj) {
        if (!(obj instanceof Timesheet)) return false;
        Timesheet other = (Timesheet) obj;
        return this.timesheetID != null && this.timesheetID.equals(other.timesheetID);
    }

    @Override
    public String toString() {
        return "Timesheet[ timesheetID=" + timesheetID + " ]";
    }
}
