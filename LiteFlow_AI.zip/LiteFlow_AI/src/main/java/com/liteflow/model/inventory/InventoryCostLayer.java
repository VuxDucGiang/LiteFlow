/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author bovlnguyn
 */
@Entity
@Table(name = "InventoryCostLayers")
public class InventoryCostLayer implements Serializable {
    @Id
    @Column(name = "LayerID", nullable = false, updatable = false, length = 36)
    private String layerID;

    @ManyToOne(optional = false)
    @JoinColumn(name = "SKUID", nullable = false)
    private SKU sku;

    @ManyToOne(optional = false)
    @JoinColumn(name = "LocationID", nullable = false)
    private InventoryLocation location;

    @ManyToOne
    @JoinColumn(name = "LotID")
    private StockLot lot;

    @Column(name = "QtyRemaining", nullable = false)
    private Integer qtyRemaining;

    @Column(name = "UnitCost", nullable = false, precision = 18, scale = 4)
    private java.math.BigDecimal unitCost;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedAt")
    private Date createdAt = new Date();
    // getters/setters

    public String getLayerID() {
        return layerID;
    }

    public void setLayerID(String layerID) {
        this.layerID = layerID;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public InventoryLocation getLocation() {
        return location;
    }

    public void setLocation(InventoryLocation location) {
        this.location = location;
    }

    public StockLot getLot() {
        return lot;
    }

    public void setLot(StockLot lot) {
        this.lot = lot;
    }

    public Integer getQtyRemaining() {
        return qtyRemaining;
    }

    public void setQtyRemaining(Integer qtyRemaining) {
        this.qtyRemaining = qtyRemaining;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    @Override
    public String toString() {
        return "InventoryCostLayer{" + "layerID=" + layerID + ", sku=" + sku + ", location=" + location + ", lot=" + lot + ", qtyRemaining=" + qtyRemaining + ", unitCost=" + unitCost + ", createdAt=" + createdAt + '}';
    }
    
}
