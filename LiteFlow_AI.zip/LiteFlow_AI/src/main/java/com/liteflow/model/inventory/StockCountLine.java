/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 *
 * @author bovlnguyn
 */
@Entity
@Table(name = "StockCountLines")
public class StockCountLine implements Serializable {
    @Id
    @Column(name = "CountLineID", nullable = false, updatable = false, length = 36)
    private String countLineID;

    @ManyToOne(optional = false) @JoinColumn(name = "CountID", nullable = false)
    private StockCount count;

    @ManyToOne(optional = false) @JoinColumn(name = "SKUID", nullable = false)
    private SKU sku;

    @Column(name = "SystemQty", nullable = false)
    private Integer systemQty;

    @Column(name = "CountedQty", nullable = false)
    private Integer countedQty;

    @Column(name = "Variance", insertable = false, updatable = false)
    private Integer variance; // computed column in DB

    public String getCountLineID() {
        return countLineID;
    }

    public void setCountLineID(String countLineID) {
        this.countLineID = countLineID;
    }

    public StockCount getCount() {
        return count;
    }

    public void setCount(StockCount count) {
        this.count = count;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public Integer getSystemQty() {
        return systemQty;
    }

    public void setSystemQty(Integer systemQty) {
        this.systemQty = systemQty;
    }

    public Integer getCountedQty() {
        return countedQty;
    }

    public void setCountedQty(Integer countedQty) {
        this.countedQty = countedQty;
    }

    public Integer getVariance() {
        return variance;
    }

    public void setVariance(Integer variance) {
        this.variance = variance;
    }

    @Override
    public String toString() {
        return "StockCountLine{" + "countLineID=" + countLineID + ", count=" + count + ", sku=" + sku + ", systemQty=" + systemQty + ", countedQty=" + countedQty + ", variance=" + variance + '}';
    }
    
}
