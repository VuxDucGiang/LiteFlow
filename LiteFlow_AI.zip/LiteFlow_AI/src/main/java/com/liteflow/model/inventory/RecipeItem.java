/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author bovlnguyn
 */
@Entity
@Table(name = "RecipeItems")
public class RecipeItem implements Serializable {
    @Id
    @Column(name = "RecipeItemID", nullable = false, updatable = false, length = 36)
    private String recipeItemID;

    @ManyToOne(optional = false)
    @JoinColumn(name = "RecipeID", nullable = false)
    private Recipe recipe;

    @ManyToOne(optional = false)
    @JoinColumn(name = "ComponentSKUID", nullable = false)
    private SKU componentSKU;

    @Column(name = "Qty", nullable = false, precision = 18, scale = 4)
    private java.math.BigDecimal qty;

    @Column(name = "Unit", length = 20)
    private String unit;
    // getters/setters

    public String getRecipeItemID() {
        return recipeItemID;
    }

    public void setRecipeItemID(String recipeItemID) {
        this.recipeItemID = recipeItemID;
    }

    public Recipe getRecipe() {
        return recipe;
    }

    public void setRecipe(Recipe recipe) {
        this.recipe = recipe;
    }

    public SKU getComponentSKU() {
        return componentSKU;
    }

    public void setComponentSKU(SKU componentSKU) {
        this.componentSKU = componentSKU;
    }

    public BigDecimal getQty() {
        return qty;
    }

    public void setQty(BigDecimal qty) {
        this.qty = qty;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    @Override
    public String toString() {
        return "RecipeItem{" + "recipeItemID=" + recipeItemID + ", recipe=" + recipe + ", componentSKU=" + componentSKU + ", qty=" + qty + ", unit=" + unit + '}';
    }
    
}
