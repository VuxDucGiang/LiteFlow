/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.sales;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "EInvoices")
@NamedQueries({
    @NamedQuery(name = "EInvoice.findAll", query = "SELECT e FROM EInvoice e"),
    @NamedQuery(name = "EInvoice.findByInvoiceID", query = "SELECT e FROM EInvoice e WHERE e.invoiceID = :invoiceID"),
    @NamedQuery(name = "EInvoice.findByExternalRef", query = "SELECT e FROM EInvoice e WHERE e.externalRef = :externalRef"),
    @NamedQuery(name = "EInvoice.findByStatus", query = "SELECT e FROM EInvoice e WHERE e.status = :status"),
    @NamedQuery(name = "EInvoice.findByIssuedAt", query = "SELECT e FROM EInvoice e WHERE e.issuedAt = :issuedAt")})
public class EInvoice implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "InvoiceID")
    private String invoiceID;
    @Size(max = 200)
    @Column(name = "ExternalRef")
    private String externalRef;
    @Size(max = 50)
    @Column(name = "Status")
    private String status;
    @Column(name = "IssuedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date issuedAt;
    @JoinColumn(name = "OrderID", referencedColumnName = "OrderID")
    @ManyToOne
    private SalesOrder orderID;

    public EInvoice() {
    }

    public EInvoice(String invoiceID) {
        this.invoiceID = invoiceID;
    }

    public String getInvoiceID() {
        return invoiceID;
    }

    public void setInvoiceID(String invoiceID) {
        this.invoiceID = invoiceID;
    }

    public String getExternalRef() {
        return externalRef;
    }

    public void setExternalRef(String externalRef) {
        this.externalRef = externalRef;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(Date issuedAt) {
        this.issuedAt = issuedAt;
    }

    public SalesOrder getOrderID() {
        return orderID;
    }

    public void setOrderID(SalesOrder orderID) {
        this.orderID = orderID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invoiceID != null ? invoiceID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof EInvoice)) {
            return false;
        }
        EInvoice other = (EInvoice) object;
        if ((this.invoiceID == null && other.invoiceID != null) || (this.invoiceID != null && !this.invoiceID.equals(other.invoiceID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.EInvoice[ invoiceID=" + invoiceID + " ]";
    }
    
}
