package com.liteflow.model.auth;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "Users")
public class User implements Serializable {

    @Id
    @Column(name = "UserID", nullable = false, updatable = false)
    private UUID userID = UUID.randomUUID();

    @Column(name = "Email", length = 320, unique = true)
    private String email;

    @Column(name = "Phone", length = 32, unique = true)
    private String phone;

    @Column(name = "GoogleID", length = 200)
    private String googleID;

    @Column(name = "PasswordHash")
    private String passwordHash;

    @Column(name = "TwoFactorSecret", length = 200)
    private String twoFactorSecret;

    @Column(name = "DisplayName", length = 200)
    private String displayName;

    @Column(name = "IsActive")
    private Boolean isActive = true;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedAt", updatable = false)
    private Date createdAt;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "UpdatedAt")
    private Date updatedAt;

    @Lob
    @Column(name = "Meta")
    private String meta;

    @ManyToMany(fetch = FetchType.EAGER)
    @JoinTable(
            name = "UserRoles",
            joinColumns = @JoinColumn(name = "UserID"),
            inverseJoinColumns = @JoinColumn(name = "RoleID")
    )

    private Collection<Role> roles;

    // ===== Lifecycle hooks =====
    @PrePersist
    protected void onCreate() {
        createdAt = new Date();
        updatedAt = new Date();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedAt = new Date();
    }

    // ===== Constructors =====
    public User() {
    }

    public User(String email, String passwordHash, String displayName) {
        this.email = email;
        this.passwordHash = passwordHash;
        this.displayName = displayName;
    }

    // ===== Getter & Setter =====
    public UUID getUserID() {
        return userID;
    }

    public void setUserID(UUID userID) {
        this.userID = userID;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getGoogleID() {
        return googleID;
    }

    public void setGoogleID(String googleID) {
        this.googleID = googleID;
    }

    public String getPasswordHash() {
        return passwordHash;
    }

    public void setPasswordHash(String passwordHash) {
        this.passwordHash = passwordHash;
    }

    public String getTwoFactorSecret() {
        return twoFactorSecret;
    }

    public void setTwoFactorSecret(String twoFactorSecret) {
        this.twoFactorSecret = twoFactorSecret;
    }

    public String getDisplayName() {
        return displayName;
    }

    public void setDisplayName(String displayName) {
        this.displayName = displayName;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    /**
     * Helper để tránh lỗi Boolean vs int
     *
     * @return
     */
    public boolean isActiveSafe() {
        return Boolean.TRUE.equals(isActive);
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public String getMeta() {
        return meta;
    }

    public void setMeta(String meta) {
        this.meta = meta;
    }

    public Collection<Role> getRoles() {
        return roles;
    }

    public void setRoles(Collection<Role> roles) {
        this.roles = roles;
    }

    // ===== Helper =====
    public boolean hasRole(String roleName) {
        if (roles == null) {
            return false;
        }
        return roles.stream().anyMatch(r -> r.getName().equalsIgnoreCase(roleName));
    }

    /**
     * Lấy role chính (nếu có)
     *
     * @return
     */
    public String getPrimaryRoleName() {
        if (roles != null && !roles.isEmpty()) {
            return roles.iterator().next().getName();
        }
        return null;
    }

    /**
     * Helper: set một role duy nhất cho user (dùng khi tạo user tạm từ JWT/SSO)
     *
     * @param roleName
     */
    public void setSingleRole(String roleName) {
        Role r = new Role();
        r.setName(roleName);
        this.roles = Set.of(r);
    }

    @Override
    public String toString() {
        return "User{"
                + "userID=" + userID
                + ", email='" + email + '\''
                + ", displayName='" + displayName + '\''
                + '}';
    }
}
