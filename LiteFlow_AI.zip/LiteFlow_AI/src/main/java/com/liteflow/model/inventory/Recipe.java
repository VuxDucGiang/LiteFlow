/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

/**
 *
 * @author bovlnguyn
 */
import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.*;

@Entity
@Table(name = "Recipes")
public class Recipe implements Serializable {
    @Id
    @Column(name = "RecipeID", nullable = false, updatable = false, length = 36)
    private String recipeID;

    @ManyToOne(optional = false)
    @JoinColumn(name = "ProductID", nullable = false)
    private Product product;

    @Column(name = "Version", nullable = false)
    private Integer version = 1;

    @Column(name = "IsActive")
    private Boolean isActive = true;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedAt")
    private Date createdAt = new Date();

    @OneToMany(mappedBy = "recipe", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<RecipeItem> items = new ArrayList<>();
    // getters/setters

    public String getRecipeID() {
        return recipeID;
    }

    public void setRecipeID(String recipeID) {
        this.recipeID = recipeID;
    }

    public Product getProduct() {
        return product;
    }

    public void setProduct(Product product) {
        this.product = product;
    }

    public Integer getVersion() {
        return version;
    }

    public void setVersion(Integer version) {
        this.version = version;
    }

    public Boolean getIsActive() {
        return isActive;
    }

    public void setIsActive(Boolean isActive) {
        this.isActive = isActive;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public List<RecipeItem> getItems() {
        return items;
    }

    public void setItems(List<RecipeItem> items) {
        this.items = items;
    }

    @Override
    public String toString() {
        return "Recipe{" + "recipeID=" + recipeID + ", product=" + product + ", version=" + version + ", isActive=" + isActive + ", createdAt=" + createdAt + ", items=" + items + '}';
    }
    
}