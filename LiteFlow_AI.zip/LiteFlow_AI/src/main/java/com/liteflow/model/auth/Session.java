package com.liteflow.model.auth;

import jakarta.persistence.*;
import java.io.Serializable;
import java.time.LocalDateTime;
import java.util.UUID;

@Entity
@Table(name = "Sessions")
public class Session implements Serializable {

    @Id
    @GeneratedValue
    @Column(name = "SessionID", columnDefinition = "uniqueidentifier")
    private UUID sessionId;

    @Column(name = "UserID", columnDefinition = "uniqueidentifier", nullable = false)
    private UUID userId;

    @Column(name = "JWT")
    private String jwt;

    @Column(name = "DeviceInfo")
    private String deviceInfo;

    @Column(name = "IPAddress")
    private String ipAddress;

    @Column(name = "CreatedAt")
    private LocalDateTime createdAt;

    @Column(name = "ExpiresAt")
    private LocalDateTime expiresAt;

    @Column(name = "Revoked")
    private boolean revoked;

    // Getter & Setter
    public UUID getSessionId() { return sessionId; }
    public void setSessionId(UUID sessionId) { this.sessionId = sessionId; }

    public UUID getUserId() { return userId; }
    public void setUserId(UUID userId) { this.userId = userId; }

    public String getJwt() { return jwt; }
    public void setJwt(String jwt) { this.jwt = jwt; }

    public String getDeviceInfo() { return deviceInfo; }
    public void setDeviceInfo(String deviceInfo) { this.deviceInfo = deviceInfo; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public LocalDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(LocalDateTime expiresAt) { this.expiresAt = expiresAt; }

    public boolean isRevoked() { return revoked; }
    public void setRevoked(boolean revoked) { this.revoked = revoked; }
}
