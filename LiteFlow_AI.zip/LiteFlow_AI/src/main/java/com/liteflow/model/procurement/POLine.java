/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.procurement;

import com.liteflow.model.inventory.SKU;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "POLines")
@NamedQueries({
    @NamedQuery(name = "POLine.findAll", query = "SELECT p FROM POLine p"),
    @NamedQuery(name = "POLine.findByPOLineID", query = "SELECT p FROM POLine p WHERE p.pOLineID = :pOLineID"),
    @NamedQuery(name = "POLine.findByQuantity", query = "SELECT p FROM POLine p WHERE p.quantity = :quantity"),
    @NamedQuery(name = "POLine.findByUnitPrice", query = "SELECT p FROM POLine p WHERE p.unitPrice = :unitPrice")})
public class POLine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "POLineID")
    private String pOLineID;
    @Column(name = "Quantity")
    private Integer quantity;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "UnitPrice")
    private BigDecimal unitPrice;
    @JoinColumn(name = "POID", referencedColumnName = "POID")
    @ManyToOne
    private PurchaseOrder poid;
    
    @ManyToOne
    @JoinColumn(name = "SKUID", referencedColumnName = "SKUID")
    private SKU sku;

    
    public POLine() {
    }

    public POLine(String pOLineID) {
        this.pOLineID = pOLineID;
    }

    public String getPOLineID() {
        return pOLineID;
    }

    public void setPOLineID(String pOLineID) {
        this.pOLineID = pOLineID;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public PurchaseOrder getPoid() {
        return poid;
    }

    public void setPoid(PurchaseOrder poid) {
        this.poid = poid;
    }

    public SKU getSkuid() {
        return sku;
    }

    public void setSkuid(SKU sku) {
        this.sku = sku;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (pOLineID != null ? pOLineID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof POLine)) {
            return false;
        }
        POLine other = (POLine) object;
        if ((this.pOLineID == null && other.pOLineID != null) || (this.pOLineID != null && !this.pOLineID.equals(other.pOLineID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.POLine[ pOLineID=" + pOLineID + " ]";
    }
    
}
