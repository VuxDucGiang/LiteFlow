/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.auth;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "AuditLogs")
@NamedQueries({
    @NamedQuery(name = "AuditLog.findAll", query = "SELECT a FROM AuditLog a"),
    @NamedQuery(name = "AuditLog.findByAuditID", query = "SELECT a FROM AuditLog a WHERE a.auditID = :auditID"),
    @NamedQuery(name = "AuditLog.findByAction", query = "SELECT a FROM AuditLog a WHERE a.action = :action"),
    @NamedQuery(name = "AuditLog.findByObjectType", query = "SELECT a FROM AuditLog a WHERE a.objectType = :objectType"),
    @NamedQuery(name = "AuditLog.findByObjectID", query = "SELECT a FROM AuditLog a WHERE a.objectID = :objectID"),
    @NamedQuery(name = "AuditLog.findByDetails", query = "SELECT a FROM AuditLog a WHERE a.details = :details"),
    @NamedQuery(name = "AuditLog.findByIPAddress", query = "SELECT a FROM AuditLog a WHERE a.iPAddress = :iPAddress"),
    @NamedQuery(name = "AuditLog.findByCreatedAt", query = "SELECT a FROM AuditLog a WHERE a.createdAt = :createdAt")})
public class AuditLog implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "AuditID")
    private String auditID;
    @Size(max = 200)
    @Column(name = "Action")
    private String action;
    @Size(max = 100)
    @Column(name = "ObjectType")
    private String objectType;
    @Size(max = 36)
    @Column(name = "ObjectID")
    private String objectID;
    @Size(max = 2147483647)
    @Column(name = "Details")
    private String details;
    @Size(max = 50)
    @Column(name = "IPAddress")
    private String iPAddress;
    @Column(name = "CreatedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @JoinColumn(name = "UserID", referencedColumnName = "UserID")
    @ManyToOne
    private User userID;

    public AuditLog() {
    }

    public AuditLog(String auditID) {
        this.auditID = auditID;
    }

    public String getAuditID() {
        return auditID;
    }

    public void setAuditID(String auditID) {
        this.auditID = auditID;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String getObjectType() {
        return objectType;
    }

    public void setObjectType(String objectType) {
        this.objectType = objectType;
    }

    public String getObjectID() {
        return objectID;
    }

    public void setObjectID(String objectID) {
        this.objectID = objectID;
    }

    public String getDetails() {
        return details;
    }

    public void setDetails(String details) {
        this.details = details;
    }

    public String getIPAddress() {
        return iPAddress;
    }

    public void setIPAddress(String iPAddress) {
        this.iPAddress = iPAddress;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public User getUserID() {
        return userID;
    }

    public void setUserID(User userID) {
        this.userID = userID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (auditID != null ? auditID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof AuditLog)) {
            return false;
        }
        AuditLog other = (AuditLog) object;
        return !((this.auditID == null && other.auditID != null) || (this.auditID != null && !this.auditID.equals(other.auditID)));
    }

    @Override
    public String toString() {
        return "com.liteflow.model.AuditLog[ auditID=" + auditID + " ]";
    }
    
}
