/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.EmbeddedId;
import jakarta.persistence.Entity;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.MapsId;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import java.io.Serializable;

/**
 * StockLevel: tổng tồn theo (SKUID, LocationID)
 * - Dùng @MapsId để khóa tổng hợp map trực tiếp vào 2 quan hệ sku/location.
 */
@Entity
@Table(name = "StockLevels")
@NamedQueries({
    @NamedQuery(name = "StockLevel.findAll",
                query = "SELECT s FROM StockLevel s"),
    @NamedQuery(name = "StockLevel.findBySkuid",
                query = "SELECT s FROM StockLevel s WHERE s.stockLevelPK.skuid = :skuid"),
    @NamedQuery(name = "StockLevel.findByLocationID",
                query = "SELECT s FROM StockLevel s WHERE s.stockLevelPK.locationID = :locationID"),
    @NamedQuery(name = "StockLevel.findByQuantity",
                query = "SELECT s FROM StockLevel s WHERE s.quantity = :quantity"),
    @NamedQuery(name = "StockLevel.findBySkuAndLocation",
                query = "SELECT s FROM StockLevel s WHERE s.stockLevelPK.skuid = :skuid AND s.stockLevelPK.locationID = :locationID")
})
public class StockLevel implements Serializable {

    private static final long serialVersionUID = 1L;

    @EmbeddedId
    protected StockLevelPK stockLevelPK;

    @Column(name = "Quantity")
    private Integer quantity = 0;

    /** Quan hệ tới kho – map vào khóa tổng hợp locationID */
    @MapsId("locationID")
    @JoinColumn(name = "LocationID", referencedColumnName = "LocationID", nullable = false)
    @ManyToOne(optional = false)
    private InventoryLocation inventoryLocation;

    /** Quan hệ tới SKU – map vào khóa tổng hợp skuid */
    @MapsId("skuid")
    @JoinColumn(name = "SKUID", referencedColumnName = "SKUID", nullable = false)
    @ManyToOne(optional = false)
    private SKU sku;

    public StockLevel() {
    }

    public StockLevel(StockLevelPK stockLevelPK) {
        this.stockLevelPK = stockLevelPK;
    }

    public StockLevel(String skuid, String locationID) {
        this.stockLevelPK = new StockLevelPK(skuid, locationID);
    }

    @PrePersist
    protected void onCreate() {
        if (this.quantity == null) this.quantity = 0;
    }

    public StockLevelPK getStockLevelPK() {
        return stockLevelPK;
    }

    public void setStockLevelPK(StockLevelPK stockLevelPK) {
        this.stockLevelPK = stockLevelPK;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public InventoryLocation getInventoryLocation() {
        return inventoryLocation;
    }

    public void setInventoryLocation(InventoryLocation inventoryLocation) {
        this.inventoryLocation = inventoryLocation;
        if (inventoryLocation != null) {
            if (this.stockLevelPK == null) this.stockLevelPK = new StockLevelPK();
            this.stockLevelPK.setLocationID(inventoryLocation.getLocationID());
        }
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
        if (sku != null) {
            if (this.stockLevelPK == null) this.stockLevelPK = new StockLevelPK();
            this.stockLevelPK.setSkuid(sku.getSkuid());
        }
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (stockLevelPK != null ? stockLevelPK.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof StockLevel)) {
            return false;
        }
        StockLevel other = (StockLevel) object;
        if (this.stockLevelPK == null && other.stockLevelPK != null) return false;
        return this.stockLevelPK != null && this.stockLevelPK.equals(other.stockLevelPK);
    }

    @Override
    public String toString() {
        return "com.liteflow.model.inventory.StockLevel[ stockLevelPK=" + stockLevelPK + " ]";
    }
}
