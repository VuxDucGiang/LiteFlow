/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.procurement;

import com.liteflow.model.auth.User;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "PurchaseOrders")
@NamedQueries({
    @NamedQuery(name = "PurchaseOrder.findAll", query = "SELECT p FROM PurchaseOrder p"),
    @NamedQuery(name = "PurchaseOrder.findByPoid", query = "SELECT p FROM PurchaseOrder p WHERE p.poid = :poid"),
    @NamedQuery(name = "PurchaseOrder.findByStatus", query = "SELECT p FROM PurchaseOrder p WHERE p.status = :status"),
    @NamedQuery(name = "PurchaseOrder.findByApprovedAt", query = "SELECT p FROM PurchaseOrder p WHERE p.approvedAt = :approvedAt"),
    @NamedQuery(name = "PurchaseOrder.findByCreatedAt", query = "SELECT p FROM PurchaseOrder p WHERE p.createdAt = :createdAt")})
public class PurchaseOrder implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "POID")
    private String poid;
    @Size(max = 50)
    @Column(name = "Status")
    private String status;
    @Column(name = "ApprovedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date approvedAt;
    @Column(name = "CreatedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @OneToMany(mappedBy = "purchaseOrder")
    private Collection<GoodsReceipt> goodsReceiptCollection;
    @OneToMany(mappedBy = "poid")
    private Collection<SupplierInvoice> supplierInvoiceCollection;
    @OneToMany(mappedBy = "poid")
    private Collection<POLine> pOLineCollection;
    @JoinColumn(name = "SupplierID", referencedColumnName = "SupplierID")
    @ManyToOne
    private Supplier supplierID;
    @JoinColumn(name = "CreatedBy", referencedColumnName = "UserID")
    @ManyToOne
    private User createdBy;
    @JoinColumn(name = "ApprovedBy", referencedColumnName = "UserID")
    @ManyToOne
    private User approvedBy;

    public PurchaseOrder() {
    }

    public PurchaseOrder(String poid) {
        this.poid = poid;
    }

    public String getPoid() {
        return poid;
    }

    public void setPoid(String poid) {
        this.poid = poid;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getApprovedAt() {
        return approvedAt;
    }

    public void setApprovedAt(Date approvedAt) {
        this.approvedAt = approvedAt;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Collection<GoodsReceipt> getGoodsReceiptCollection() {
        return goodsReceiptCollection;
    }

    public void setGoodsReceiptCollection(Collection<GoodsReceipt> goodsReceiptCollection) {
        this.goodsReceiptCollection = goodsReceiptCollection;
    }

    public Collection<SupplierInvoice> getSupplierInvoiceCollection() {
        return supplierInvoiceCollection;
    }

    public void setSupplierInvoiceCollection(Collection<SupplierInvoice> supplierInvoiceCollection) {
        this.supplierInvoiceCollection = supplierInvoiceCollection;
    }

    public Collection<POLine> getPOLineCollection() {
        return pOLineCollection;
    }

    public void setPOLineCollection(Collection<POLine> pOLineCollection) {
        this.pOLineCollection = pOLineCollection;
    }

    public Supplier getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(Supplier supplierID) {
        this.supplierID = supplierID;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public User getApprovedBy() {
        return approvedBy;
    }

    public void setApprovedBy(User approvedBy) {
        this.approvedBy = approvedBy;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (poid != null ? poid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PurchaseOrder)) {
            return false;
        }
        PurchaseOrder other = (PurchaseOrder) object;
        if ((this.poid == null && other.poid != null) || (this.poid != null && !this.poid.equals(other.poid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.PurchaseOrder[ poid=" + poid + " ]";
    }
    
}
