/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.auth;

import jakarta.persistence.*;
import java.io.Serializable;
import java.util.UUID;

@Entity
@Table(name = "UserRoles")
@IdClass(UserRolePK.class) // Khóa chính tổng hợp
public class UserRole implements Serializable {

    @Id
    @Column(name = "UserID")
    private UUID userId;

    @Id
    @Column(name = "RoleID")
    private UUID roleId;

    // Quan hệ Many-to-One đến User
    @ManyToOne
    @JoinColumn(name = "UserID", insertable = false, updatable = false)
    private User user;

    // Quan hệ Many-to-One đến Role
    @ManyToOne
    @JoinColumn(name = "RoleID", insertable = false, updatable = false)
    private Role role;

    // Constructor mặc định
    public UserRole() {}

    public UserRole(UUID userId, UUID roleId) {
        this.userId = userId;
        this.roleId = roleId;
    }

    // Getter & Setter
    public UUID getUserId() {
        return userId;
    }

    public void setUserId(UUID userId) {
        this.userId = userId;
    }

    public UUID getRoleId() {
        return roleId;
    }

    public void setRoleId(UUID roleId) {
        this.roleId = roleId;
    }

    public User getUser() {
        return user;
    }

    public Role getRole() {
        return role;
    }
}