/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.Lob;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Collection;

@Entity
@Table(name = "Products")
@NamedQueries({
    @NamedQuery(name = "Product.findAll",                query = "SELECT p FROM Product p"),
    @NamedQuery(name = "Product.findByProductID",        query = "SELECT p FROM Product p WHERE p.productID = :productID"),
    @NamedQuery(name = "Product.findByName",             query = "SELECT p FROM Product p WHERE p.name = :name"),
    @NamedQuery(name = "Product.findByLegacyCategory",   query = "SELECT p FROM Product p WHERE p.legacyCategory = :legacyCategory"),
    @NamedQuery(name = "Product.findByProductCode",      query = "SELECT p FROM Product p WHERE p.productCode = :productCode"),
    @NamedQuery(name = "Product.findByStatus",           query = "SELECT p FROM Product p WHERE p.status = :status")
})
public class Product implements Serializable {

    private static final long serialVersionUID = 1L;

    // ===== Keys =====
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "ProductID")
    private String productID;

    // ===== Basics =====
    @Size(max = 200)
    @Column(name = "Name")
    private String name;

    @Size(max = 100)
    @Column(name = "Category")
    private String legacyCategory;

    /** Mã sản phẩm (duy nhất) */
    @Size(max = 100)
    @Column(name = "ProductCode", unique = true)
    private String productCode;

    /** Thương hiệu */
    @Size(max = 100)
    @Column(name = "Brand")
    private String brand;

    /** Đơn vị tính mặc định (cup, liter, shot, ...) */
    @Size(max = 50)
    @Column(name = "UOM")
    private String uom;

    /** Sản phẩm composite (có BOM/Recipe) */
    @Column(name = "IsComposite")
    private Boolean isComposite = Boolean.FALSE;

    /** JSON thuộc tính SPU (ví dụ: {"spuAttrs":["size"]}) */
    @Lob
    @Column(name = "Attributes")
    private String attributes;

    /** Trạng thái (ACTIVE/INACTIVE...) */
    @Size(max = 20)
    @Column(name = "Status")
    private String status = "ACTIVE";

    /** Thông tin mở rộng */
    @Lob
    @Column(name = "Meta")
    private String meta;

    // ===== Relations =====

    /** Quan hệ phân loại mới qua CategoryID (có thể null nếu chưa gắn danh mục mới) */
    @ManyToOne
    @JoinColumn(name = "CategoryID")
    private Category category;

    /**
     * Danh sách SKU thuộc SPU này.
     * YÊU CẦU: Trong SKU phải có field 'product' với @ManyToOne@JoinColumn(name="ProductID")
     */
    @OneToMany(mappedBy = "product")
    private Collection<SKU> skuCollection;

    // ===== Constructors =====
    public Product() {
    }

    public Product(String productID) {
        this.productID = productID;
    }

    // ===== Getters/Setters =====
    public String getProductID() { return productID; }
    public void setProductID(String productID) { this.productID = productID; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    /** legacy text category */
    public String getLegacyCategory() { return legacyCategory; }
    public void setLegacyCategory(String legacyCategory) { this.legacyCategory = legacyCategory; }

    public String getProductCode() { return productCode; }
    public void setProductCode(String productCode) { this.productCode = productCode; }

    public String getBrand() { return brand; }
    public void setBrand(String brand) { this.brand = brand; }

    public String getUom() { return uom; }
    public void setUom(String uom) { this.uom = uom; }

    public Boolean getIsComposite() { return isComposite; }
    public void setIsComposite(Boolean isComposite) { this.isComposite = isComposite; }

    public String getAttributes() { return attributes; }
    public void setAttributes(String attributes) { this.attributes = attributes; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMeta() { return meta; }
    public void setMeta(String meta) { this.meta = meta; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public Collection<SKU> getSkuCollection() { return skuCollection; }
    public void setSkuCollection(Collection<SKU> skuCollection) { this.skuCollection = skuCollection; }

    // ===== Equality =====
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (productID != null ? productID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof Product)) return false;
        Product other = (Product) object;
        if (this.productID == null && other.productID != null) return false;
        return this.productID != null && this.productID.equals(other.productID);
    }

    @Override
    public String toString() {
        return "com.liteflow.model.inventory.Product[ productID=" + productID + " ]";
    }
}
