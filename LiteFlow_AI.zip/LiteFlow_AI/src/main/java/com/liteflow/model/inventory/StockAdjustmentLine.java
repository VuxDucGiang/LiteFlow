/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author bovlnguyn
 */
@Entity
@Table(name = "StockAdjustmentLines")
public class StockAdjustmentLine implements Serializable {
    @Id
    @Column(name = "AdjustmentLineID", nullable = false, updatable = false, length = 36)
    private String adjustmentLineID;

    @ManyToOne(optional = false) @JoinColumn(name = "AdjustmentID", nullable = false)
    private StockAdjustment adjustment;

    @ManyToOne(optional = false) @JoinColumn(name = "SKUID", nullable = false)
    private SKU sku;

    @ManyToOne @JoinColumn(name = "LotID")
    private StockLot lot; // optional

    @Column(name = "Qty", nullable = false)
    private Integer qty; // + in / - out

    @Column(name = "UnitCost", precision = 18, scale = 4)
    private java.math.BigDecimal unitCost;

    public String getAdjustmentLineID() {
        return adjustmentLineID;
    }

    public void setAdjustmentLineID(String adjustmentLineID) {
        this.adjustmentLineID = adjustmentLineID;
    }

    public StockAdjustment getAdjustment() {
        return adjustment;
    }

    public void setAdjustment(StockAdjustment adjustment) {
        this.adjustment = adjustment;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public StockLot getLot() {
        return lot;
    }

    public void setLot(StockLot lot) {
        this.lot = lot;
    }

    public Integer getQty() {
        return qty;
    }

    public void setQty(Integer qty) {
        this.qty = qty;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }

    @Override
    public String toString() {
        return "StockAdjustmentLine{" + "adjustmentLineID=" + adjustmentLineID + ", adjustment=" + adjustment + ", sku=" + sku + ", lot=" + lot + ", qty=" + qty + ", unitCost=" + unitCost + '}';
    }
    
}
