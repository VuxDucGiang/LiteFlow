/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.hr;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "PayrollLines")
@NamedQueries({
    @NamedQuery(name = "PayrollLine.findAll", query = "SELECT p FROM PayrollLine p"),
    @NamedQuery(name = "PayrollLine.findByPayrollLineID", query = "SELECT p FROM PayrollLine p WHERE p.payrollLineID = :payrollLineID"),
    @NamedQuery(name = "PayrollLine.findByBaseSalary", query = "SELECT p FROM PayrollLine p WHERE p.baseSalary = :baseSalary"),
    @NamedQuery(name = "PayrollLine.findByAllowance", query = "SELECT p FROM PayrollLine p WHERE p.allowance = :allowance"),
    @NamedQuery(name = "PayrollLine.findByBonus", query = "SELECT p FROM PayrollLine p WHERE p.bonus = :bonus"),
    @NamedQuery(name = "PayrollLine.findByDeductions", query = "SELECT p FROM PayrollLine p WHERE p.deductions = :deductions"),
    @NamedQuery(name = "PayrollLine.findByNetPay", query = "SELECT p FROM PayrollLine p WHERE p.netPay = :netPay")})
public class PayrollLine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "PayrollLineID")
    private String payrollLineID;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "BaseSalary")
    private BigDecimal baseSalary;
    @Column(name = "Allowance")
    private BigDecimal allowance;
    @Column(name = "Bonus")
    private BigDecimal bonus;
    @Column(name = "Deductions")
    private BigDecimal deductions;
    @Column(name = "NetPay")
    private BigDecimal netPay;
    @JoinColumn(name = "EmployeeID", referencedColumnName = "EmployeeID")
    @ManyToOne
    private Employee employeeID;
    @JoinColumn(name = "PayrollID", referencedColumnName = "PayrollID")
    @ManyToOne
    private PayrollRun payrollID;

    public PayrollLine() {
    }

    public PayrollLine(String payrollLineID) {
        this.payrollLineID = payrollLineID;
    }

    public String getPayrollLineID() {
        return payrollLineID;
    }

    public void setPayrollLineID(String payrollLineID) {
        this.payrollLineID = payrollLineID;
    }

    public BigDecimal getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(BigDecimal baseSalary) {
        this.baseSalary = baseSalary;
    }

    public BigDecimal getAllowance() {
        return allowance;
    }

    public void setAllowance(BigDecimal allowance) {
        this.allowance = allowance;
    }

    public BigDecimal getBonus() {
        return bonus;
    }

    public void setBonus(BigDecimal bonus) {
        this.bonus = bonus;
    }

    public BigDecimal getDeductions() {
        return deductions;
    }

    public void setDeductions(BigDecimal deductions) {
        this.deductions = deductions;
    }

    public BigDecimal getNetPay() {
        return netPay;
    }

    public void setNetPay(BigDecimal netPay) {
        this.netPay = netPay;
    }

    public Employee getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Employee employeeID) {
        this.employeeID = employeeID;
    }

    public PayrollRun getPayrollID() {
        return payrollID;
    }

    public void setPayrollID(PayrollRun payrollID) {
        this.payrollID = payrollID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (payrollLineID != null ? payrollLineID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof PayrollLine)) {
            return false;
        }
        PayrollLine other = (PayrollLine) object;
        if ((this.payrollLineID == null && other.payrollLineID != null) || (this.payrollLineID != null && !this.payrollLineID.equals(other.payrollLineID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.PayrollLine[ payrollLineID=" + payrollLineID + " ]";
    }
    
}
