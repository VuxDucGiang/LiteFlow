/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.hr;

import com.liteflow.model.sales.SalesOrder;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "SalesCommissions")
@NamedQueries({
    @NamedQuery(name = "SalesCommission.findAll", query = "SELECT s FROM SalesCommission s"),
    @NamedQuery(name = "SalesCommission.findByCommissionID", query = "SELECT s FROM SalesCommission s WHERE s.commissionID = :commissionID"),
    @NamedQuery(name = "SalesCommission.findByAmount", query = "SELECT s FROM SalesCommission s WHERE s.amount = :amount"),
    @NamedQuery(name = "SalesCommission.findByCreatedAt", query = "SELECT s FROM SalesCommission s WHERE s.createdAt = :createdAt")})
public class SalesCommission implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "CommissionID")
    private String commissionID;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Amount")
    private BigDecimal amount;
    @Column(name = "CreatedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @JoinColumn(name = "EmployeeID", referencedColumnName = "EmployeeID")
    @ManyToOne
    private Employee employeeID;
    @JoinColumn(name = "OrderID", referencedColumnName = "OrderID")
    @ManyToOne
    private SalesOrder orderID;

    public SalesCommission() {
    }

    public SalesCommission(String commissionID) {
        this.commissionID = commissionID;
    }

    public String getCommissionID() {
        return commissionID;
    }

    public void setCommissionID(String commissionID) {
        this.commissionID = commissionID;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Employee getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(Employee employeeID) {
        this.employeeID = employeeID;
    }

    public SalesOrder getOrderID() {
        return orderID;
    }

    public void setOrderID(SalesOrder orderID) {
        this.orderID = orderID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (commissionID != null ? commissionID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalesCommission)) {
            return false;
        }
        SalesCommission other = (SalesCommission) object;
        if ((this.commissionID == null && other.commissionID != null) || (this.commissionID != null && !this.commissionID.equals(other.commissionID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.SalesCommission[ commissionID=" + commissionID + " ]";
    }
    
}
