package com.liteflow.model.inventory;

import com.liteflow.model.ai.Forecast;
import com.liteflow.model.procurement.GoodsReceipt;
import com.liteflow.model.procurement.POLine;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Collection;
import java.util.Date;

@Entity
@Table(name = "SKUs")
@NamedQueries({
    @NamedQuery(name = "SKU.findAll", query = "SELECT s FROM SKU s"),
    @NamedQuery(name = "SKU.findBySkuid", query = "SELECT s FROM SKU s WHERE s.skuid = :skuid"),
    @NamedQuery(name = "SKU.findByCode", query = "SELECT s FROM SKU s WHERE s.code = :code"),
    @NamedQuery(name = "SKU.findByBarcode", query = "SELECT s FROM SKU s WHERE s.barcode = :barcode"),
    @NamedQuery(name = "SKU.findByAttributes", query = "SELECT s FROM SKU s WHERE s.attributes = :attributes"),
    @NamedQuery(name = "SKU.findByExpiryDate", query = "SELECT s FROM SKU s WHERE s.expiryDate = :expiryDate")
})
public class SKU implements Serializable {

    private static final long serialVersionUID = 1L;

    // ===== Key =====
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "SKUID")
    private String skuid;

    // ===== Basics =====
    @Size(max = 100)
    @Column(name = "Code", unique = true)
    private String code;

    @Size(max = 64)
    @Column(name = "Barcode", unique = true)
    private String barcode;

    @Lob
    @Column(name = "Attributes")
    private String attributes;

    @Temporal(TemporalType.DATE)
    @Column(name = "ExpiryDate")
    private Date expiryDate;

    // ===== Relations =====
    @JoinColumn(name = "ProductID", referencedColumnName = "ProductID")
    @ManyToOne(optional = false)
    private Product product;

    @OneToMany(mappedBy = "sku")
    private Collection<GoodsReceipt> goodsReceiptCollection;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "sku")
    private Collection<StockLevel> stockLevelCollection;

    @OneToMany(mappedBy = "sku")
    private Collection<StockMovement> stockMovementCollection;

    @OneToMany(mappedBy = "sku")
    private Collection<Forecast> forecastCollection;

    @OneToMany(mappedBy = "sku")
    private Collection<POLine> pOLineCollection;

    @OneToMany(mappedBy = "sku")
    private Collection<StockLot> stockLots;

    @OneToMany(mappedBy = "sku")
    private Collection<InventoryCostLayer> costLayers;

    @OneToMany(mappedBy = "sku")
    private Collection<ReorderPolicy> reorderPolicies;

    @OneToMany(mappedBy = "sku")
    private Collection<StockCountLine> stockCountLines;

    @OneToMany(mappedBy = "sku")
    private Collection<StockAdjustmentLine> stockAdjustmentLines;

    // ===== Constructors =====
    public SKU() {}
    public SKU(String skuid) { this.skuid = skuid; }

    // ===== Getters/Setters =====
    public String getSkuid() { return skuid; }
    public void setSkuid(String skuid) { this.skuid = skuid; }

    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }

    public String getBarcode() { return barcode; }
    public void setBarcode(String barcode) { this.barcode = barcode; }

    public String getAttributes() { return attributes; }
    public void setAttributes(String attributes) { this.attributes = attributes; }

    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date expiryDate) { this.expiryDate = expiryDate; }

    public Product getProduct() { return product; }
    public void setProduct(Product product) { this.product = product; }

    public Collection<GoodsReceipt> getGoodsReceiptCollection() { return goodsReceiptCollection; }
    public void setGoodsReceiptCollection(Collection<GoodsReceipt> goodsReceiptCollection) { this.goodsReceiptCollection = goodsReceiptCollection; }

    public Collection<StockLevel> getStockLevelCollection() { return stockLevelCollection; }
    public void setStockLevelCollection(Collection<StockLevel> stockLevelCollection) { this.stockLevelCollection = stockLevelCollection; }

    public Collection<StockMovement> getStockMovementCollection() { return stockMovementCollection; }
    public void setStockMovementCollection(Collection<StockMovement> stockMovementCollection) { this.stockMovementCollection = stockMovementCollection; }

    public Collection<Forecast> getForecastCollection() { return forecastCollection; }
    public void setForecastCollection(Collection<Forecast> forecastCollection) { this.forecastCollection = forecastCollection; }

    public Collection<POLine> getPOLineCollection() { return pOLineCollection; }
    public void setPOLineCollection(Collection<POLine> pOLineCollection) { this.pOLineCollection = pOLineCollection; }

    public Collection<StockLot> getStockLots() { return stockLots; }
    public void setStockLots(Collection<StockLot> stockLots) { this.stockLots = stockLots; }

    public Collection<InventoryCostLayer> getCostLayers() { return costLayers; }
    public void setCostLayers(Collection<InventoryCostLayer> costLayers) { this.costLayers = costLayers; }

    public Collection<ReorderPolicy> getReorderPolicies() { return reorderPolicies; }
    public void setReorderPolicies(Collection<ReorderPolicy> reorderPolicies) { this.reorderPolicies = reorderPolicies; }

    public Collection<StockCountLine> getStockCountLines() { return stockCountLines; }
    public void setStockCountLines(Collection<StockCountLine> stockCountLines) { this.stockCountLines = stockCountLines; }

    public Collection<StockAdjustmentLine> getStockAdjustmentLines() { return stockAdjustmentLines; }
    public void setStockAdjustmentLines(Collection<StockAdjustmentLine> stockAdjustmentLines) { this.stockAdjustmentLines = stockAdjustmentLines; }

    @Override
    public int hashCode() { return (skuid != null ? skuid.hashCode() : 0); }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof SKU)) return false;
        SKU other = (SKU) object;
        return this.skuid != null && this.skuid.equals(other.skuid);
    }

    @Override
    public String toString() { return "com.liteflow.model.inventory.SKU[ skuid=" + skuid + " ]"; }
}
