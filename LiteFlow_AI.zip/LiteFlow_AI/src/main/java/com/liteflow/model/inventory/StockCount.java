/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.model.auth.User;
import jakarta.persistence.*;
import java.io.Serializable;
import java.util.*;

@Entity
@Table(name = "StockCounts")
public class StockCount implements Serializable {
    @Id
    @Column(name = "CountID", nullable = false, updatable = false, length = 36)
    private String countID;

    @ManyToOne(optional = false) @JoinColumn(name = "LocationID", nullable = false)
    private InventoryLocation location;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CountDate")
    private Date countDate = new Date();

    @Column(name = "Status", length = 20)
    private String status = "DRAFT";

    @ManyToOne @JoinColumn(name = "CreatedBy")
    private User createdBy;

    @OneToMany(mappedBy = "count", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<StockCountLine> lines = new ArrayList<>();
    // getters/setters

    public String getCountID() {
        return countID;
    }

    public void setCountID(String countID) {
        this.countID = countID;
    }

    public InventoryLocation getLocation() {
        return location;
    }

    public void setLocation(InventoryLocation location) {
        this.location = location;
    }

    public Date getCountDate() {
        return countDate;
    }

    public void setCountDate(Date countDate) {
        this.countDate = countDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public List<StockCountLine> getLines() {
        return lines;
    }

    public void setLines(List<StockCountLine> lines) {
        this.lines = lines;
    }

    @Override
    public String toString() {
        return "StockCount{" + "countID=" + countID + ", location=" + location + ", countDate=" + countDate + ", status=" + status + ", createdBy=" + createdBy + ", lines=" + lines + '}';
    }
    
}
