/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * StockMovement: ghi nhận mọi biến động kho (IN/OUT/TRANSFER/ADJUSTMENT)
 * - Sửa field: location (thay vì locationID), sku (thay vì skuid)
 * - Bổ sung: lot (LotID), unitCost, refType, refID
 * - createdAt set mặc định khi persist
 *
 * @author bovlnguyn
 */
@Entity
@Table(name = "StockMovements")
@NamedQueries({
    @NamedQuery(name = "StockMovement.findAll",
                query = "SELECT s FROM StockMovement s"),
    @NamedQuery(name = "StockMovement.findByMovementID",
                query = "SELECT s FROM StockMovement s WHERE s.movementID = :movementID"),
    @NamedQuery(name = "StockMovement.findByQuantity",
                query = "SELECT s FROM StockMovement s WHERE s.quantity = :quantity"),
    @NamedQuery(name = "StockMovement.findByType",
                query = "SELECT s FROM StockMovement s WHERE s.type = :type"),
    @NamedQuery(name = "StockMovement.findByReference",
                query = "SELECT s FROM StockMovement s WHERE s.reference = :reference"),
    @NamedQuery(name = "StockMovement.findByCreatedAt",
                query = "SELECT s FROM StockMovement s WHERE s.createdAt = :createdAt"),
    @NamedQuery(name = "StockMovement.findByRefType",
                query = "SELECT s FROM StockMovement s WHERE s.refType = :refType"),
    @NamedQuery(name = "StockMovement.findBySkuAndRange",
                query = "SELECT s FROM StockMovement s WHERE s.sku.skuid = :skuId AND s.createdAt BETWEEN :from AND :to ORDER BY s.createdAt ASC")
})
public class StockMovement implements Serializable {

    private static final long serialVersionUID = 1L;

    // ===== Columns =====
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "MovementID")
    private String movementID;

    @Column(name = "Quantity")
    private Integer quantity;

    /** IN / OUT / TRANSFER / ADJUSTMENT */
    @Size(max = 50)
    @Column(name = "Type")
    private String type;

    /** Tham chiếu hiển thị (ví dụ: "GRN-<POID>", "SO-xxxx") */
    @Size(max = 200)
    @Column(name = "Reference")
    private String reference;

    /** Loại chứng từ gốc: PO / SO / TRANSFER / ADJUSTMENT ... */
    @Size(max = 50)
    @Column(name = "RefType")
    private String refType;

    /** ID chứng từ gốc (GUID dạng text) */
    @Size(max = 36)
    @Column(name = "RefID")
    private String refID;

    /** Giá vốn đơn vị gắn với movement (hỗ trợ FIFO/điều chỉnh) */
    @Column(name = "UnitCost", precision = 18, scale = 4)
    private BigDecimal unitCost;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "CreatedAt")
    private Date createdAt;

    // ===== Relations =====

    /** Kho/vị trí – khớp với InventoryLocation.stockMovementCollection (mappedBy="location") */
    @JoinColumn(name = "LocationID", referencedColumnName = "LocationID")
    @ManyToOne(optional = false)
    private InventoryLocation location;

    /** SKU – khớp với SKU.stockMovementCollection (mappedBy="sku") */
    @JoinColumn(name = "SKUID", referencedColumnName = "SKUID")
    @ManyToOne(optional = false)
    private SKU sku;

    /** Lô (FEFO) – optional */
    @JoinColumn(name = "LotID", referencedColumnName = "LotID")
    @ManyToOne
    private StockLot lot;

    // ===== Lifecycle =====
    @PrePersist
    protected void onCreate() {
        if (this.createdAt == null) {
            this.createdAt = new Date();
        }
    }

    // ===== Constructors =====
    public StockMovement() { }

    public StockMovement(String movementID) {
        this.movementID = movementID;
    }

    // ===== Getters/Setters =====
    public String getMovementID() { return movementID; }
    public void setMovementID(String movementID) { this.movementID = movementID; }

    public Integer getQuantity() { return quantity; }
    public void setQuantity(Integer quantity) { this.quantity = quantity; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getReference() { return reference; }
    public void setReference(String reference) { this.reference = reference; }

    public String getRefType() { return refType; }
    public void setRefType(String refType) { this.refType = refType; }

    public String getRefID() { return refID; }
    public void setRefID(String refID) { this.refID = refID; }

    public BigDecimal getUnitCost() { return unitCost; }
    public void setUnitCost(BigDecimal unitCost) { this.unitCost = unitCost; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public InventoryLocation getLocation() { return location; }
    public void setLocation(InventoryLocation location) { this.location = location; }

    public SKU getSku() { return sku; }
    public void setSku(SKU sku) { this.sku = sku; }

    public StockLot getLot() { return lot; }
    public void setLot(StockLot lot) { this.lot = lot; }

    // ===== Equality =====
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (movementID != null ? movementID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof StockMovement)) return false;
        StockMovement other = (StockMovement) object;
        if (this.movementID == null && other.movementID != null) return false;
        return this.movementID != null && this.movementID.equals(other.movementID);
    }

    @Override
    public String toString() {
        return "com.liteflow.model.inventory.StockMovement[ movementID=" + movementID + " ]";
    }
}
