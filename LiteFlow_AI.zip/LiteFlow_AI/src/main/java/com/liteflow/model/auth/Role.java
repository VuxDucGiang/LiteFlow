package com.liteflow.model.auth;

import jakarta.persistence.*;
import java.util.UUID;

@Entity
@Table(name = "Roles")
public class Role {

    @Id
    @Column(name = "RoleID", columnDefinition = "uniqueidentifier")
    private UUID roleID;

    @Column(name = "Name")
    private String name;

    @Column(name = "Description")
    private String description;

    // Getter & Setter
    public UUID getRoleID() {
        return roleID;
    }

    public void setRoleID(UUID roleID) {
        this.roleID = roleID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }
}
