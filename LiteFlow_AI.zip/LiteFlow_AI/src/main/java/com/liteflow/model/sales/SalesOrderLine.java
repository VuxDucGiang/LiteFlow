/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.sales;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "SalesOrderLines")
@NamedQueries({
    @NamedQuery(name = "SalesOrderLine.findAll", query = "SELECT s FROM SalesOrderLine s"),
    @NamedQuery(name = "SalesOrderLine.findByLineID", query = "SELECT s FROM SalesOrderLine s WHERE s.lineID = :lineID"),
    @NamedQuery(name = "SalesOrderLine.findByProductID", query = "SELECT s FROM SalesOrderLine s WHERE s.productID = :productID"),
    @NamedQuery(name = "SalesOrderLine.findBySku", query = "SELECT s FROM SalesOrderLine s WHERE s.sku = :sku"),
    @NamedQuery(name = "SalesOrderLine.findByQuantity", query = "SELECT s FROM SalesOrderLine s WHERE s.quantity = :quantity"),
    @NamedQuery(name = "SalesOrderLine.findByUnitPrice", query = "SELECT s FROM SalesOrderLine s WHERE s.unitPrice = :unitPrice"),
    @NamedQuery(name = "SalesOrderLine.findByDiscount", query = "SELECT s FROM SalesOrderLine s WHERE s.discount = :discount"),
    @NamedQuery(name = "SalesOrderLine.findByLineTotal", query = "SELECT s FROM SalesOrderLine s WHERE s.lineTotal = :lineTotal")})
public class SalesOrderLine implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "LineID")
    private String lineID;
    @Size(max = 36)
    @Column(name = "ProductID")
    private String productID;
    @Size(max = 100)
    @Column(name = "SKU")
    private String sku;
    @Column(name = "Quantity")
    private Integer quantity;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "UnitPrice")
    private BigDecimal unitPrice;
    @Column(name = "Discount")
    private BigDecimal discount;
    @Column(name = "LineTotal")
    private BigDecimal lineTotal;
    @JoinColumn(name = "OrderID", referencedColumnName = "OrderID")
    @ManyToOne
    private SalesOrder orderID;

    public SalesOrderLine() {
    }

    public SalesOrderLine(String lineID) {
        this.lineID = lineID;
    }

    public String getLineID() {
        return lineID;
    }

    public void setLineID(String lineID) {
        this.lineID = lineID;
    }

    public String getProductID() {
        return productID;
    }

    public void setProductID(String productID) {
        this.productID = productID;
    }

    public String getSku() {
        return sku;
    }

    public void setSku(String sku) {
        this.sku = sku;
    }

    public Integer getQuantity() {
        return quantity;
    }

    public void setQuantity(Integer quantity) {
        this.quantity = quantity;
    }

    public BigDecimal getUnitPrice() {
        return unitPrice;
    }

    public void setUnitPrice(BigDecimal unitPrice) {
        this.unitPrice = unitPrice;
    }

    public BigDecimal getDiscount() {
        return discount;
    }

    public void setDiscount(BigDecimal discount) {
        this.discount = discount;
    }

    public BigDecimal getLineTotal() {
        return lineTotal;
    }

    public void setLineTotal(BigDecimal lineTotal) {
        this.lineTotal = lineTotal;
    }

    public SalesOrder getOrderID() {
        return orderID;
    }

    public void setOrderID(SalesOrder orderID) {
        this.orderID = orderID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (lineID != null ? lineID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalesOrderLine)) {
            return false;
        }
        SalesOrderLine other = (SalesOrderLine) object;
        if ((this.lineID == null && other.lineID != null) || (this.lineID != null && !this.lineID.equals(other.lineID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.SalesOrderLine[ lineID=" + lineID + " ]";
    }
    
}
