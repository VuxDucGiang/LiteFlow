/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Basic;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Collection;

/**
 * InventoryLocation: kho/vị trí lưu trữ (STAGE, STORAGE, ...)
 *
 * Chỉnh sửa:
 * - stockMovementCollection: mappedBy = "location" (trước đây là "locationID")
 * - Bổ sung các quan hệ cho Inventory mở rộng:
 *   + stockLots (FEFO), costLayers (FIFO), reorderPolicies (ROP),
 *     stockCounts (kiểm kê), stockAdjustments (điều chỉnh)
 * - Giữ stockLevelCollection mappedBy = "inventoryLocation" để tương thích với entity hiện tại.
 */
@Entity
@Table(name = "InventoryLocations")
@NamedQueries({
    @NamedQuery(name = "InventoryLocation.findAll",          query = "SELECT i FROM InventoryLocation i"),
    @NamedQuery(name = "InventoryLocation.findByLocationID", query = "SELECT i FROM InventoryLocation i WHERE i.locationID = :locationID"),
    @NamedQuery(name = "InventoryLocation.findByBranch",     query = "SELECT i FROM InventoryLocation i WHERE i.branch = :branch"),
    @NamedQuery(name = "InventoryLocation.findByName",       query = "SELECT i FROM InventoryLocation i WHERE i.name = :name"),
    @NamedQuery(name = "InventoryLocation.findByType",       query = "SELECT i FROM InventoryLocation i WHERE i.type = :type"),
    @NamedQuery(name = "InventoryLocation.findByAddress",    query = "SELECT i FROM InventoryLocation i WHERE i.address = :address")
})
public class InventoryLocation implements Serializable {

    private static final long serialVersionUID = 1L;

    // ===== Columns =====
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "LocationID")
    private String locationID;

    @Size(max = 100)
    @Column(name = "Branch")
    private String branch;

    @Size(max = 200)
    @Column(name = "Name")
    private String name;

    /** Ví dụ: STAGE / STORAGE (có thể map enum ở layer trên) */
    @Size(max = 50)
    @Column(name = "Type")
    private String type;

    @Size(max = 500)
    @Column(name = "Address")
    private String address;

    // ===== Relations =====

    /** Tổng tồn (StockLevels) – composite key; entity StockLevel hiện đang dùng field 'inventoryLocation' */
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "inventoryLocation")
    private Collection<StockLevel> stockLevelCollection;

    /** Sổ kho (movements) – dùng field 'location' trong StockMovement */
    @OneToMany(mappedBy = "location")
    private Collection<StockMovement> stockMovementCollection;

    /** Các lô (FEFO) – dùng field 'location' trong StockLot */
    @OneToMany(mappedBy = "location")
    private Collection<StockLot> stockLots;

    /** Lớp giá vốn (FIFO) – dùng field 'location' trong InventoryCostLayer */
    @OneToMany(mappedBy = "location")
    private Collection<InventoryCostLayer> costLayers;

    /** Chính sách ROP/Reorder – dùng field 'location' trong ReorderPolicy */
    @OneToMany(mappedBy = "location")
    private Collection<ReorderPolicy> reorderPolicies;

    /** Phiếu kiểm kê – dùng field 'location' trong StockCount */
    @OneToMany(mappedBy = "location")
    private Collection<StockCount> stockCounts;

    /** Phiếu điều chỉnh kho – dùng field 'location' trong StockAdjustment */
    @OneToMany(mappedBy = "location")
    private Collection<StockAdjustment> stockAdjustments;

    // ===== Constructors =====
    public InventoryLocation() {
    }

    public InventoryLocation(String locationID) {
        this.locationID = locationID;
    }

    // ===== Getters/Setters =====
    public String getLocationID() { return locationID; }
    public void setLocationID(String locationID) { this.locationID = locationID; }

    public String getBranch() { return branch; }
    public void setBranch(String branch) { this.branch = branch; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public Collection<StockLevel> getStockLevelCollection() { return stockLevelCollection; }
    public void setStockLevelCollection(Collection<StockLevel> stockLevelCollection) { this.stockLevelCollection = stockLevelCollection; }

    public Collection<StockMovement> getStockMovementCollection() { return stockMovementCollection; }
    public void setStockMovementCollection(Collection<StockMovement> stockMovementCollection) { this.stockMovementCollection = stockMovementCollection; }

    public Collection<StockLot> getStockLots() { return stockLots; }
    public void setStockLots(Collection<StockLot> stockLots) { this.stockLots = stockLots; }

    public Collection<InventoryCostLayer> getCostLayers() { return costLayers; }
    public void setCostLayers(Collection<InventoryCostLayer> costLayers) { this.costLayers = costLayers; }

    public Collection<ReorderPolicy> getReorderPolicies() { return reorderPolicies; }
    public void setReorderPolicies(Collection<ReorderPolicy> reorderPolicies) { this.reorderPolicies = reorderPolicies; }

    public Collection<StockCount> getStockCounts() { return stockCounts; }
    public void setStockCounts(Collection<StockCount> stockCounts) { this.stockCounts = stockCounts; }

    public Collection<StockAdjustment> getStockAdjustments() { return stockAdjustments; }
    public void setStockAdjustments(Collection<StockAdjustment> stockAdjustments) { this.stockAdjustments = stockAdjustments; }

    // ===== Equality =====
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (locationID != null ? locationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof InventoryLocation)) {
            return false;
        }
        InventoryLocation other = (InventoryLocation) object;
        if ((this.locationID == null && other.locationID != null) || (this.locationID != null && !this.locationID.equals(other.locationID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.inventory.InventoryLocation[ locationID=" + locationID + " ]";
    }   
}
