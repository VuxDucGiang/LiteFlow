/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.ai;

import com.liteflow.model.inventory.SKU;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "Forecasts")
@NamedQueries({
    @NamedQuery(name = "Forecast.findAll", query = "SELECT f FROM Forecast f"),
    @NamedQuery(name = "Forecast.findByForecastID", query = "SELECT f FROM Forecast f WHERE f.forecastID = :forecastID"),
    @NamedQuery(name = "Forecast.findByForecastDate", query = "SELECT f FROM Forecast f WHERE f.forecastDate = :forecastDate"),
    @NamedQuery(name = "Forecast.findByPredictedDemand", query = "SELECT f FROM Forecast f WHERE f.predictedDemand = :predictedDemand"),
    @NamedQuery(name = "Forecast.findByCreatedAt", query = "SELECT f FROM Forecast f WHERE f.createdAt = :createdAt")})
public class Forecast implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "ForecastID")
    private String forecastID;
    @Column(name = "ForecastDate")
    @Temporal(TemporalType.DATE)
    private Date forecastDate;
    @Column(name = "PredictedDemand")
    private Integer predictedDemand;
    @Column(name = "CreatedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @JoinColumn(name = "SKU", referencedColumnName = "SKUID")
    @ManyToOne
    private SKU sku;

    public Forecast() {
    }

    public Forecast(String forecastID) {
        this.forecastID = forecastID;
    }

    public String getForecastID() {
        return forecastID;
    }

    public void setForecastID(String forecastID) {
        this.forecastID = forecastID;
    }

    public Date getForecastDate() {
        return forecastDate;
    }

    public void setForecastDate(Date forecastDate) {
        this.forecastDate = forecastDate;
    }

    public Integer getPredictedDemand() {
        return predictedDemand;
    }

    public void setPredictedDemand(Integer predictedDemand) {
        this.predictedDemand = predictedDemand;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (forecastID != null ? forecastID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Forecast)) {
            return false;
        }
        Forecast other = (Forecast) object;
        if ((this.forecastID == null && other.forecastID != null) || (this.forecastID != null && !this.forecastID.equals(other.forecastID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.Forecast[ forecastID=" + forecastID + " ]";
    }
    
}
