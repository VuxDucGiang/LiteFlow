/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.hr;

import com.liteflow.model.auth.User;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "Employees")
@NamedQueries({
    @NamedQuery(name = "Employee.findAll", query = "SELECT e FROM Employee e"),
    @NamedQuery(name = "Employee.findByEmployeeID", query = "SELECT e FROM Employee e WHERE e.employeeID = :employeeID"),
    @NamedQuery(name = "Employee.findByFullName", query = "SELECT e FROM Employee e WHERE e.fullName = :fullName"),
    @NamedQuery(name = "Employee.findByPosition", query = "SELECT e FROM Employee e WHERE e.position = :position"),
    @NamedQuery(name = "Employee.findByHireDate", query = "SELECT e FROM Employee e WHERE e.hireDate = :hireDate"),
    @NamedQuery(name = "Employee.findByBaseSalary", query = "SELECT e FROM Employee e WHERE e.baseSalary = :baseSalary"),
    @NamedQuery(name = "Employee.findByMeta", query = "SELECT e FROM Employee e WHERE e.meta = :meta")})
public class Employee implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "EmployeeID")
    private String employeeID;
    @Size(max = 200)
    @Column(name = "FullName")
    private String fullName;
    @Size(max = 100)
    @Column(name = "Position")
    private String position;
    @Column(name = "HireDate")
    @Temporal(TemporalType.DATE)
    private Date hireDate;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "BaseSalary")
    private BigDecimal baseSalary;
    @Size(max = 2147483647)
    @Column(name = "Meta")
    private String meta;
    @JoinColumn(name = "UserID", referencedColumnName = "UserID")
    @ManyToOne
    private User userID;
    @OneToMany(mappedBy = "employeeID")
    private Collection<LeaveRequest> leaveRequestCollection;
    @OneToMany(mappedBy = "employeeID")
    private Collection<Shift> shiftCollection;
    @OneToMany(mappedBy = "employeeID")
    private Collection<Timesheet> timesheetCollection;
    @OneToMany(mappedBy = "employeeID")
    private Collection<PayrollLine> payrollLineCollection;
    @OneToMany(mappedBy = "employeeID")
    private Collection<SalesCommission> salesCommissionCollection;

    public Employee() {
    }

    public Employee(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getEmployeeID() {
        return employeeID;
    }

    public void setEmployeeID(String employeeID) {
        this.employeeID = employeeID;
    }

    public String getFullName() {
        return fullName;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public BigDecimal getBaseSalary() {
        return baseSalary;
    }

    public void setBaseSalary(BigDecimal baseSalary) {
        this.baseSalary = baseSalary;
    }

    public String getMeta() {
        return meta;
    }

    public void setMeta(String meta) {
        this.meta = meta;
    }

    public User getUserID() {
        return userID;
    }

    public void setUserID(User userID) {
        this.userID = userID;
    }

    public Collection<LeaveRequest> getLeaveRequestCollection() {
        return leaveRequestCollection;
    }

    public void setLeaveRequestCollection(Collection<LeaveRequest> leaveRequestCollection) {
        this.leaveRequestCollection = leaveRequestCollection;
    }

    public Collection<Shift> getShiftCollection() {
        return shiftCollection;
    }

    public void setShiftCollection(Collection<Shift> shiftCollection) {
        this.shiftCollection = shiftCollection;
    }

    public Collection<Timesheet> getTimesheetCollection() {
        return timesheetCollection;
    }

    public void setTimesheetCollection(Collection<Timesheet> timesheetCollection) {
        this.timesheetCollection = timesheetCollection;
    }

    public Collection<PayrollLine> getPayrollLineCollection() {
        return payrollLineCollection;
    }

    public void setPayrollLineCollection(Collection<PayrollLine> payrollLineCollection) {
        this.payrollLineCollection = payrollLineCollection;
    }

    public Collection<SalesCommission> getSalesCommissionCollection() {
        return salesCommissionCollection;
    }

    public void setSalesCommissionCollection(Collection<SalesCommission> salesCommissionCollection) {
        this.salesCommissionCollection = salesCommissionCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (employeeID != null ? employeeID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Employee)) {
            return false;
        }
        Employee other = (Employee) object;
        if ((this.employeeID == null && other.employeeID != null) || (this.employeeID != null && !this.employeeID.equals(other.employeeID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.Employee[ employeeID=" + employeeID + " ]";
    }
    
}
