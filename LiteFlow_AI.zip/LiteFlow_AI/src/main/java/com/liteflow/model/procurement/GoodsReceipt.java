package com.liteflow.model.procurement;

import com.liteflow.model.inventory.SKU;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.util.Date;

@Entity
@Table(name = "GoodsReceipts")
@NamedQueries({
    @NamedQuery(name = "GoodsReceipt.findAll", query = "SELECT g FROM GoodsReceipt g"),
    @NamedQuery(name = "GoodsReceipt.findByReceiptID", query = "SELECT g FROM GoodsReceipt g WHERE g.receiptID = :receiptID"),
    @NamedQuery(name = "GoodsReceipt.findByQuantityReceived", query = "SELECT g FROM GoodsReceipt g WHERE g.quantityReceived = :quantityReceived"),
    @NamedQuery(name = "GoodsReceipt.findByReceivedAt", query = "SELECT g FROM GoodsReceipt g WHERE g.receivedAt = :receivedAt")
})
public class GoodsReceipt implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "ReceiptID")
    private String receiptID;

    @Column(name = "QuantityReceived")
    private Integer quantityReceived;

    @Column(name = "ReceivedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date receivedAt;

    @JoinColumn(name = "POID", referencedColumnName = "POID")
    @ManyToOne
    private PurchaseOrder purchaseOrder;

    @JoinColumn(name = "SKUID", referencedColumnName = "SKUID")
    @ManyToOne
    private SKU sku;

    public GoodsReceipt() {}
    public GoodsReceipt(String receiptID) { this.receiptID = receiptID; }

    public String getReceiptID() { return receiptID; }
    public void setReceiptID(String receiptID) { this.receiptID = receiptID; }

    public Integer getQuantityReceived() { return quantityReceived; }
    public void setQuantityReceived(Integer quantityReceived) { this.quantityReceived = quantityReceived; }

    public Date getReceivedAt() { return receivedAt; }
    public void setReceivedAt(Date receivedAt) { this.receivedAt = receivedAt; }

    public PurchaseOrder getPurchaseOrder() { return purchaseOrder; }
    public void setPurchaseOrder(PurchaseOrder purchaseOrder) { this.purchaseOrder = purchaseOrder; }

    public SKU getSku() { return sku; }
    public void setSku(SKU sku) { this.sku = sku; }

    @Override
    public int hashCode() { return (receiptID != null ? receiptID.hashCode() : 0); }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof GoodsReceipt)) return false;
        GoodsReceipt other = (GoodsReceipt) object;
        return this.receiptID != null && this.receiptID.equals(other.receiptID);
    }

    @Override
    public String toString() { return "com.liteflow.model.procurement.GoodsReceipt[ receiptID=" + receiptID + " ]"; }
}
