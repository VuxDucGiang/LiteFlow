/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

/**
 *
 * @author bovlnguyn
 */
import jakarta.persistence.*;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Entity
@Table(name = "StockLots")
public class StockLot implements Serializable {
    @Id
    @Column(name = "LotID", nullable = false, updatable = false, length = 36)
    private String lotID;

    @ManyToOne(optional = false)
    @JoinColumn(name = "SKUID", nullable = false)
    private SKU sku;

    @ManyToOne(optional = false)
    @JoinColumn(name = "LocationID", nullable = false)
    private InventoryLocation location;

    @Column(name = "BatchNo", length = 100)
    private String batchNo;

    @Temporal(TemporalType.DATE)
    @Column(name = "ExpiryDate")
    private Date expiryDate;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "ReceivedAt")
    private Date receivedAt = new Date();

    @Column(name = "UnitCost", precision = 18, scale = 4)
    private java.math.BigDecimal unitCost;

    @Column(name = "QtyOnHand")
    private Integer qtyOnHand = 0;

    public String getLotID() {
        return lotID;
    }

    public void setLotID(String lotID) {
        this.lotID = lotID;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public InventoryLocation getLocation() {
        return location;
    }

    public void setLocation(InventoryLocation location) {
        this.location = location;
    }

    public String getBatchNo() {
        return batchNo;
    }

    public void setBatchNo(String batchNo) {
        this.batchNo = batchNo;
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }

    public Date getReceivedAt() {
        return receivedAt;
    }

    public void setReceivedAt(Date receivedAt) {
        this.receivedAt = receivedAt;
    }

    public BigDecimal getUnitCost() {
        return unitCost;
    }

    public void setUnitCost(BigDecimal unitCost) {
        this.unitCost = unitCost;
    }

    public Integer getQtyOnHand() {
        return qtyOnHand;
    }

    public void setQtyOnHand(Integer qtyOnHand) {
        this.qtyOnHand = qtyOnHand;
    }

    @Override
    public String toString() {
        return "StockLot{" + "lotID=" + lotID + ", sku=" + sku + ", location=" + location + ", batchNo=" + batchNo + ", expiryDate=" + expiryDate + ", receivedAt=" + receivedAt + ", unitCost=" + unitCost + ", qtyOnHand=" + qtyOnHand + '}';
    }
    
}

