/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.auth;


import java.io.Serializable;
import java.util.Objects;
import java.util.UUID;

public class UserRolePK implements Serializable {
    private UUID userId;
    private UUID roleId;

    public UserRolePK() {}

    public UserRolePK(UUID userId, UUID roleId) {
        this.userId = userId;
        this.roleId = roleId;
    }

    // equals & hashCode (bắt buộc cho composite key)
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof UserRolePK)) return false;
        UserRolePK that = (UserRolePK) o;
        return Objects.equals(userId, that.userId) &&
               Objects.equals(roleId, that.roleId);
    }

    @Override
    public int hashCode() {
        return Objects.hash(userId, roleId);
    }
}