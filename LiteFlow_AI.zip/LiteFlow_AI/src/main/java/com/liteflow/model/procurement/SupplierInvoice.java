/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.procurement;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "SupplierInvoices")
@NamedQueries({
    @NamedQuery(name = "SupplierInvoice.findAll", query = "SELECT s FROM SupplierInvoice s"),
    @NamedQuery(name = "SupplierInvoice.findByInvoiceID", query = "SELECT s FROM SupplierInvoice s WHERE s.invoiceID = :invoiceID"),
    @NamedQuery(name = "SupplierInvoice.findByAmount", query = "SELECT s FROM SupplierInvoice s WHERE s.amount = :amount"),
    @NamedQuery(name = "SupplierInvoice.findByStatus", query = "SELECT s FROM SupplierInvoice s WHERE s.status = :status"),
    @NamedQuery(name = "SupplierInvoice.findByIssuedAt", query = "SELECT s FROM SupplierInvoice s WHERE s.issuedAt = :issuedAt"),
    @NamedQuery(name = "SupplierInvoice.findByPaidAt", query = "SELECT s FROM SupplierInvoice s WHERE s.paidAt = :paidAt")})
public class SupplierInvoice implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "InvoiceID")
    private String invoiceID;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "Amount")
    private BigDecimal amount;
    @Size(max = 50)
    @Column(name = "Status")
    private String status;
    @Column(name = "IssuedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date issuedAt;
    @Column(name = "PaidAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date paidAt;
    @JoinColumn(name = "POID", referencedColumnName = "POID")
    @ManyToOne
    private PurchaseOrder poid;
    @JoinColumn(name = "SupplierID", referencedColumnName = "SupplierID")
    @ManyToOne
    private Supplier supplierID;

    public SupplierInvoice() {
    }

    public SupplierInvoice(String invoiceID) {
        this.invoiceID = invoiceID;
    }

    public String getInvoiceID() {
        return invoiceID;
    }

    public void setInvoiceID(String invoiceID) {
        this.invoiceID = invoiceID;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getIssuedAt() {
        return issuedAt;
    }

    public void setIssuedAt(Date issuedAt) {
        this.issuedAt = issuedAt;
    }

    public Date getPaidAt() {
        return paidAt;
    }

    public void setPaidAt(Date paidAt) {
        this.paidAt = paidAt;
    }

    public PurchaseOrder getPoid() {
        return poid;
    }

    public void setPoid(PurchaseOrder poid) {
        this.poid = poid;
    }

    public Supplier getSupplierID() {
        return supplierID;
    }

    public void setSupplierID(Supplier supplierID) {
        this.supplierID = supplierID;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (invoiceID != null ? invoiceID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SupplierInvoice)) {
            return false;
        }
        SupplierInvoice other = (SupplierInvoice) object;
        if ((this.invoiceID == null && other.invoiceID != null) || (this.invoiceID != null && !this.invoiceID.equals(other.invoiceID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.SupplierInvoice[ invoiceID=" + invoiceID + " ]";
    }
    
}
