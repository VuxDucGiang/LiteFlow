/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.sales;

import com.liteflow.model.hr.SalesCommission;
import com.liteflow.model.auth.User;
import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.NamedQueries;
import jakarta.persistence.NamedQuery;
import jakarta.persistence.OneToMany;
import jakarta.persistence.Table;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Collection;
import java.util.Date;

/**
 *
 * @author VuxDucGiang
 */
@Entity
@Table(name = "SalesOrders")
@NamedQueries({
    @NamedQuery(name = "SalesOrder.findAll", query = "SELECT s FROM SalesOrder s"),
    @NamedQuery(name = "SalesOrder.findByOrderID", query = "SELECT s FROM SalesOrder s WHERE s.orderID = :orderID"),
    @NamedQuery(name = "SalesOrder.findByBranch", query = "SELECT s FROM SalesOrder s WHERE s.branch = :branch"),
    @NamedQuery(name = "SalesOrder.findByOrderDate", query = "SELECT s FROM SalesOrder s WHERE s.orderDate = :orderDate"),
    @NamedQuery(name = "SalesOrder.findByStatus", query = "SELECT s FROM SalesOrder s WHERE s.status = :status"),
    @NamedQuery(name = "SalesOrder.findByTotalAmount", query = "SELECT s FROM SalesOrder s WHERE s.totalAmount = :totalAmount"),
    @NamedQuery(name = "SalesOrder.findByPromoID", query = "SELECT s FROM SalesOrder s WHERE s.promoID = :promoID"),
    @NamedQuery(name = "SalesOrder.findByCreatedAt", query = "SELECT s FROM SalesOrder s WHERE s.createdAt = :createdAt")})
public class SalesOrder implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "OrderID")
    private String orderID;
    @Size(max = 100)
    @Column(name = "Branch")
    private String branch;
    @Column(name = "OrderDate")
    @Temporal(TemporalType.TIMESTAMP)
    private Date orderDate;
    @Size(max = 50)
    @Column(name = "Status")
    private String status;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "TotalAmount")
    private BigDecimal totalAmount;
    @Size(max = 36)
    @Column(name = "PromoID")
    private String promoID;
    @Column(name = "CreatedAt")
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdAt;
    @OneToMany(mappedBy = "orderID")
    private Collection<SalesOrderLine> salesOrderLineCollection;
    @OneToMany(mappedBy = "orderID")
    private Collection<Payment> paymentCollection;
    @JoinColumn(name = "CustomerID", referencedColumnName = "CustomerID")
    @ManyToOne
    private Customer customerID;
    @JoinColumn(name = "CreatedBy", referencedColumnName = "UserID")
    @ManyToOne
    private User createdBy;
    @OneToMany(mappedBy = "orderID")
    private Collection<EInvoice> eInvoiceCollection;
    @OneToMany(mappedBy = "orderID")
    private Collection<SalesCommission> salesCommissionCollection;

    public SalesOrder() {
    }

    public SalesOrder(String orderID) {
        this.orderID = orderID;
    }

    public String getOrderID() {
        return orderID;
    }

    public void setOrderID(String orderID) {
        this.orderID = orderID;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public Date getOrderDate() {
        return orderDate;
    }

    public void setOrderDate(Date orderDate) {
        this.orderDate = orderDate;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getPromoID() {
        return promoID;
    }

    public void setPromoID(String promoID) {
        this.promoID = promoID;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Collection<SalesOrderLine> getSalesOrderLineCollection() {
        return salesOrderLineCollection;
    }

    public void setSalesOrderLineCollection(Collection<SalesOrderLine> salesOrderLineCollection) {
        this.salesOrderLineCollection = salesOrderLineCollection;
    }

    public Collection<Payment> getPaymentCollection() {
        return paymentCollection;
    }

    public void setPaymentCollection(Collection<Payment> paymentCollection) {
        this.paymentCollection = paymentCollection;
    }

    public Customer getCustomerID() {
        return customerID;
    }

    public void setCustomerID(Customer customerID) {
        this.customerID = customerID;
    }

    public User getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(User createdBy) {
        this.createdBy = createdBy;
    }

    public Collection<EInvoice> getEInvoiceCollection() {
        return eInvoiceCollection;
    }

    public void setEInvoiceCollection(Collection<EInvoice> eInvoiceCollection) {
        this.eInvoiceCollection = eInvoiceCollection;
    }

    public Collection<SalesCommission> getSalesCommissionCollection() {
        return salesCommissionCollection;
    }

    public void setSalesCommissionCollection(Collection<SalesCommission> salesCommissionCollection) {
        this.salesCommissionCollection = salesCommissionCollection;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (orderID != null ? orderID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof SalesOrder)) {
            return false;
        }
        SalesOrder other = (SalesOrder) object;
        if ((this.orderID == null && other.orderID != null) || (this.orderID != null && !this.orderID.equals(other.orderID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.SalesOrder[ orderID=" + orderID + " ]";
    }
    
}
