/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

import jakarta.persistence.Basic;
import jakarta.persistence.Column;
import jakarta.persistence.Embeddable;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import java.io.Serializable;

/**
 * Khóa chính tổng hợp cho StockLevel: (SKUID, LocationID)
 *
 * @author bovlnguyn
 */
@Embeddable
public class StockLevelPK implements Serializable {

    private static final long serialVersionUID = 1L;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "SKUID")
    private String skuid;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 36)
    @Column(name = "LocationID")
    private String locationID;

    public StockLevelPK() {
    }

    public StockLevelPK(String skuid, String locationID) {
        this.skuid = skuid;
        this.locationID = locationID;
    }

    public String getSkuid() {
        return skuid;
    }

    public void setSkuid(String skuid) {
        this.skuid = skuid;
    }

    public String getLocationID() {
        return locationID;
    }

    public void setLocationID(String locationID) {
        this.locationID = locationID;
    }

    @Override
    public int hashCode() {
        int hash = 7;
        hash = 31 * hash + (skuid != null ? skuid.hashCode() : 0);
        hash = 31 * hash + (locationID != null ? locationID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        if (!(object instanceof StockLevelPK)) {
            return false;
        }
        StockLevelPK other = (StockLevelPK) object;
        if (this.skuid == null ? other.skuid != null : !this.skuid.equals(other.skuid)) {
            return false;
        }
        if (this.locationID == null ? other.locationID != null : !this.locationID.equals(other.locationID)) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "com.liteflow.model.inventory.StockLevelPK[ skuid=" + skuid + ", locationID=" + locationID + " ]";
    }
}
