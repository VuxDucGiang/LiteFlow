/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.model.inventory;

/**
 *
 * @author bovlnguyn
 */
import jakarta.persistence.*;
import java.io.Serializable;

@Entity
@Table(name = "ReorderPolicies",
       uniqueConstraints = @UniqueConstraint(columnNames = {"SKUID","LocationID"}))
public class ReorderPolicy implements Serializable {
    @Id
    @Column(name = "PolicyID", nullable = false, updatable = false, length = 36)
    private String policyID;

    @ManyToOne(optional = false) @JoinColumn(name = "SKUID", nullable = false)
    private SKU sku;

    @ManyToOne(optional = false) @JoinColumn(name = "LocationID", nullable = false)
    private InventoryLocation location;

    @Column(name = "MinLevel", nullable = false)
    private Integer minLevel = 0;

    @Column(name = "MaxLevel")
    private Integer maxLevel;

    @Column(name = "SafetyStock")
    private Integer safetyStock;

    @Column(name = "LeadTimeDays")
    private Integer leadTimeDays;
    // getters/setters

    public String getPolicyID() {
        return policyID;
    }

    public void setPolicyID(String policyID) {
        this.policyID = policyID;
    }

    public SKU getSku() {
        return sku;
    }

    public void setSku(SKU sku) {
        this.sku = sku;
    }

    public InventoryLocation getLocation() {
        return location;
    }

    public void setLocation(InventoryLocation location) {
        this.location = location;
    }

    public Integer getMinLevel() {
        return minLevel;
    }

    public void setMinLevel(Integer minLevel) {
        this.minLevel = minLevel;
    }

    public Integer getMaxLevel() {
        return maxLevel;
    }

    public void setMaxLevel(Integer maxLevel) {
        this.maxLevel = maxLevel;
    }

    public Integer getSafetyStock() {
        return safetyStock;
    }

    public void setSafetyStock(Integer safetyStock) {
        this.safetyStock = safetyStock;
    }

    public Integer getLeadTimeDays() {
        return leadTimeDays;
    }

    public void setLeadTimeDays(Integer leadTimeDays) {
        this.leadTimeDays = leadTimeDays;
    }

    @Override
    public String toString() {
        return "ReorderPolicy{" + "policyID=" + policyID + ", sku=" + sku + ", location=" + location + ", minLevel=" + minLevel + ", maxLevel=" + maxLevel + ", safetyStock=" + safetyStock + ", leadTimeDays=" + leadTimeDays + '}';
    }
    
}
