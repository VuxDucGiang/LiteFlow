package com.liteflow.web.auth;

import com.liteflow.model.auth.User;
import com.liteflow.service.UserService;
import com.liteflow.service.AuditService;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.UUID;

@WebServlet(urlPatterns = {"/auth/reset-password"})
public class ForgotPasswordServlet extends HttpServlet {
    private final UserService userService = new UserService();
    private final AuditService audit = new AuditService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        String ip = req.getRemoteAddr();

        User u = userService.getUserByEmail(email);
        if (u == null) {
            req.setAttribute("error", "Email không tồn tại");
            req.getRequestDispatcher("/auth/forgot.jsp").forward(req, resp);
            return;
        }

        // Generate mật khẩu tạm thời
        String tempPassword = UUID.randomUUID().toString().substring(0, 8);
        boolean ok = userService.changePassword(u, tempPassword, ip);

        if (ok) {
            audit.log(u, AuditService.AuditAction.UPDATE,
                    AuditService.ObjectType.USER,
                    u.getUserID().toString(),
                    "Reset password",
                    ip);

            // TODO: gửi email thật, hiện tại mock
            System.out.println("📧 Mật khẩu tạm thời của " + email + " là: " + tempPassword);

            req.setAttribute("msg", "Mật khẩu mới đã được gửi vào email của bạn");
            req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
        } else {
            req.setAttribute("error", "Không thể reset mật khẩu");
            req.getRequestDispatcher("/auth/forgot.jsp").forward(req, resp);
        }
    }
}
