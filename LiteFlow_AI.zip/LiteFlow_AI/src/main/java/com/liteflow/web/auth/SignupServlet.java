package com.liteflow.web.auth;

import com.liteflow.model.auth.User;
import com.liteflow.service.UserService;
import com.liteflow.service.AuditService;
import com.liteflow.util.Utils; // class hashPassword bạn đã có

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.util.regex.Pattern;

@WebServlet(urlPatterns = {"/register"})
public class SignupServlet extends HttpServlet {

    private final UserService userService = new UserService();
    private final AuditService audit = new AuditService();

    // Regex cho email .com 
    private static final Pattern EMAIL_PATTERN
            = Pattern.compile("^[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.com$");

    // Regex cho password: ≥8 ký tự, ≥1 hoa, ≥1 số
    private static final Pattern PASSWORD_PATTERN
            = Pattern.compile("^(?=.*[A-Z])(?=.*\\d).{8,}$");

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String username = req.getParameter("username");
        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String confirm = req.getParameter("confirmPassword");
        String ip = req.getRemoteAddr();

        // Validate input cơ bản
        if (username == null || email == null || password == null || confirm == null) {
            req.setAttribute("error", "Vui lòng nhập đầy đủ thông tin.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Validate email
        if (!EMAIL_PATTERN.matcher(email).matches()) {
            req.setAttribute("error", "Email phải hợp lệ và kết thúc bằng .com");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Validate password
        if (!PASSWORD_PATTERN.matcher(password).matches()) {
            req.setAttribute("error", "Mật khẩu tối thiểu 8 ký tự, có ít nhất 1 chữ hoa và 1 số.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Confirm password
        if (!password.equals(confirm)) {
            req.setAttribute("error", "Mật khẩu xác nhận không khớp.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        try {
            // Check user tồn tại
            if (userService.findByEmail(email) != null) {
                req.setAttribute("error", "Email đã được đăng ký. Vui lòng đăng nhập hoặc đặt lại mật khẩu.");
                req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
                return;
            }

            // Tạo user mới
            User u = new User();
            u.setEmail(email);
            u.setDisplayName(username);
            u.setPasswordHash(Utils.hashPassword(password));
            u.setIsActive(true);

            boolean ok = userService.addUser(u);
            if (ok) {
                audit.log(u,
                        AuditService.AuditAction.CREATE,
                        AuditService.ObjectType.USER,
                        u.getUserID().toString(),
                        "User signup",
                        ip);

                resp.sendRedirect(req.getContextPath() + "/login.jsp?signup=success");
            } else {
                req.setAttribute("error", "Không thể tạo tài khoản. Vui lòng thử lại.");
                req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            }
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Lỗi hệ thống: " + e.getMessage());
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
    }
}
