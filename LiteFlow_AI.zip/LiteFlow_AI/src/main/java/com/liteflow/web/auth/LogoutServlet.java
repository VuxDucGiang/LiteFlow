package com.liteflow.web.auth;

import com.liteflow.security.JwtUtil;
import com.liteflow.service.AuditService;
import com.liteflow.model.auth.User;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Claims;

import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import java.io.IOException;

@WebServlet(urlPatterns = {"/logout"})
public class LogoutServlet extends HttpServlet {
    private final AuditService audit = new AuditService();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        Cookie[] cookies = req.getCookies();
        String jwt = null;

        // Lấy JWT từ cookie
        if (cookies != null) {
            for (Cookie c : cookies) {
                if ("LITEFLOW_TOKEN".equals(c.getName())) {
                    jwt = c.getValue();
                    break;
                }
            }
        }

        // ✅ Không revoke Redis nữa, chỉ parse để log (optional)
        if (jwt != null) {
            try {
                Jws<Claims> jws = JwtUtil.parse(jwt);
                System.out.println("🔑 Logout JWT for userId=" + jws.getBody().getSubject());
            } catch (Exception e) {
                System.err.println("❌ Lỗi parse JWT khi logout: " + e.getMessage());
            }

            // Xóa cookie
            Cookie clear = new Cookie("LITEFLOW_TOKEN", "");
            clear.setMaxAge(0);
            clear.setPath(req.getContextPath().isEmpty() ? "/" : req.getContextPath());
            clear.setHttpOnly(true);
            clear.setSecure(false); // ⚠ để false nếu dev bằng HTTP
            resp.addCookie(clear);
        }

        // Log audit logout nếu có user trong session
        HttpSession session = req.getSession(false);
        if (session != null) {
            User u = (User) session.getAttribute("UserLogin");
            if (u != null) {
                try {
                    audit.log(
                        u,
                        AuditService.AuditAction.LOGOUT,
                        AuditService.ObjectType.USER,
                        u.getUserID().toString(),
                        "User logout",
                        req.getRemoteAddr()
                    );
                } catch (Exception e) {
                    System.err.println("❌ Lỗi ghi audit log khi logout: " + e.getMessage());
                }
            }
            session.invalidate();
        }

        // Redirect về login
        resp.sendRedirect(req.getContextPath() + "/login");
    }
}
