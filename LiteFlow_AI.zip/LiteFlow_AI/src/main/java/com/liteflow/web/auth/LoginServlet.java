package com.liteflow.web.auth;

import com.liteflow.model.auth.User;
import com.liteflow.service.AuthService;
import com.liteflow.service.AuditService;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;

@WebServlet(urlPatterns = {"/login"})
public class LoginServlet extends HttpServlet {

    private final AuthService auth = new AuthService();
    private final AuditService audit = new AuditService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String id = req.getParameter("id");          // email hoặc phone
        String password = req.getParameter("password");
        String ip = req.getRemoteAddr();

        User u = auth.findByEmailOrPhone(id).orElse(null);

        // Sai tài khoản hoặc mật khẩu -> quay lại login.jsp kèm lỗi
        if (u == null || !auth.checkPassword(u, password)) {
            audit.log(
                u,  // có thể null nếu user không tồn tại
                AuditService.AuditAction.LOGIN_FAIL,
                AuditService.ObjectType.USER,
                u != null ? String.valueOf(u.getUserID()) : null,
                "Wrong credentials",
                ip
            );
            req.setAttribute("error", "Sai tài khoản hoặc mật khẩu");
            req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
            return;
        }

        // (BỎ QUA TOTP/2FA, JWT, SESSION, COOKIES — theo yêu cầu “no security”)

        // Log thành công (tuỳ chọn)
        audit.log(
            u,
            AuditService.AuditAction.LOGIN_SUCCESS,
            AuditService.ObjectType.USER,
            String.valueOf(u.getUserID()),
            "Login success (no-session mode)",
            ip
        );

        // Chuyển thẳng tới dashboard (đảm bảo /dashboard không yêu cầu session)
        resp.sendRedirect(req.getContextPath() + "/dashboard");
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
    }
}
