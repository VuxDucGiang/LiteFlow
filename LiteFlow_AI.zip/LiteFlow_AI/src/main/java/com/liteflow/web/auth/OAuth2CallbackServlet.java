package com.liteflow.web.auth;

import com.google.api.client.auth.oauth2.TokenResponse;
import com.google.api.client.auth.oauth2.Credential;
import com.google.api.client.auth.oauth2.BearerToken;
import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeTokenRequest;
import com.google.api.client.googleapis.javanet.GoogleNetHttpTransport;
import com.google.api.client.json.gson.GsonFactory;
import com.google.api.services.oauth2.Oauth2;
import com.google.api.services.oauth2.model.Userinfo;

import com.liteflow.model.auth.User;
import com.liteflow.service.UserService;
import com.liteflow.service.AuditService;
import com.liteflow.security.JwtUtil;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.security.GeneralSecurityException;
import java.util.*;

@WebServlet("/oauth2callback")
public class OAuth2CallbackServlet extends HttpServlet {

    private String clientId;
    private String clientSecret;
    private String redirectUri;

    private final UserService userService = new UserService();
    private final AuditService audit = new AuditService();

    @Override
    public void init() throws ServletException {
        clientId = getServletContext().getInitParameter("google.clientId");
        clientSecret = getServletContext().getInitParameter("google.clientSecret");
        redirectUri = getServletContext().getInitParameter("google.redirectUri");

        if (clientId == null || clientId.isBlank()) {
            throw new ServletException("Missing google.clientId in web.xml");
        }
        if (clientSecret == null || clientSecret.isBlank()) {
            throw new ServletException("Missing google.clientSecret in web.xml");
        }
        if (redirectUri == null || redirectUri.isBlank()) {
            throw new ServletException("Missing google.redirectUri in web.xml");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String code = req.getParameter("code");
        if (code == null || code.isEmpty()) {
            resp.sendRedirect(req.getContextPath() + "/login");
            return;
        }

        try {
            TokenResponse tokenResponse = new GoogleAuthorizationCodeTokenRequest(
                    GoogleNetHttpTransport.newTrustedTransport(),
                    GsonFactory.getDefaultInstance(),
                    "https://oauth2.googleapis.com/token",
                    clientId,
                    clientSecret,
                    code,
                    redirectUri
            ).execute();

            // Credential
            Credential credential = new Credential(BearerToken.authorizationHeaderAccessMethod())
                    .setFromTokenResponse(tokenResponse);

            // Oauth2 service
            Oauth2 oauth2 = new Oauth2.Builder(
                    GoogleNetHttpTransport.newTrustedTransport(),
                    GsonFactory.getDefaultInstance(),
                    credential
            ).setApplicationName("LiteFlow").build();

            Userinfo userInfo = oauth2.userinfo().get().execute();
            String email = userInfo.getEmail();
            String name = userInfo.getName();
            String googleId = userInfo.getId();

            // 4. Tìm hoặc tạo user
            User u = userService.findByEmail(email);
            if (u == null) {
                u = new User();
                u.setEmail(email);
                u.setGoogleID(googleId);
                u.setDisplayName(name);
                u.setIsActive(true);
                userService.addUser(u);

                audit.log(u, AuditService.AuditAction.CREATE,
                        AuditService.ObjectType.USER,
                        null,
                        "User created via Google SSO",
                        req.getRemoteAddr());
            }

            // 5. Tạo JWT (bỏ Redis)
            String jti = UUID.randomUUID().toString();
            Map<String, Object> claims = new HashMap<>();
            claims.put("uid", u.getUserID().toString());
            claims.put("role", u.getPrimaryRoleName());
            claims.put("jti", jti);
            claims.put("sso", true);

            String jwt = JwtUtil.createToken(u.getUserID().toString(), 86400, claims);

            // Cookie
            Cookie cookie = new Cookie("LITEFLOW_TOKEN", jwt);
            cookie.setHttpOnly(true);
            cookie.setSecure(false); // ⚠ để false khi dev HTTP, true khi deploy HTTPS
            cookie.setPath(req.getContextPath().isEmpty() ? "/" : req.getContextPath());
            cookie.setMaxAge(24 * 3600);
            resp.addCookie(cookie);

            // 6. Lưu session
            req.getSession(true).setAttribute("UserLogin", u);

            audit.log(u, AuditService.AuditAction.LOGIN_SUCCESS,
                    AuditService.ObjectType.USER,
                    u.getUserID().toString(),
                    "Google SSO login",
                    req.getRemoteAddr());

            // 7. Redirect về dashboard
            resp.sendRedirect(req.getContextPath() + "/dashboard");

        } catch (GeneralSecurityException e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath() + "/login?oauth2error=1");
        }
    }
}
