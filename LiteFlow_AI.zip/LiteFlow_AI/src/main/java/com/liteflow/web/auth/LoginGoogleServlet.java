package com.liteflow.web.auth;

import com.google.api.client.googleapis.auth.oauth2.GoogleAuthorizationCodeRequestUrl;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.util.Arrays;

/**
 * Bước 1: Redirect người dùng sang Google OAuth consent screen
 */
@WebServlet("/auth/google")
public class LoginGoogleServlet extends HttpServlet {

    private String clientId;
    private String redirectUri;

    @Override
    public void init() throws ServletException {
        clientId = getServletContext().getInitParameter("google.clientId");
        redirectUri = getServletContext().getInitParameter("google.redirectUri");

        if (clientId == null || clientId.isBlank()) {
            throw new ServletException("❌ Missing google.clientId in web.xml");
        }
        if (redirectUri == null || redirectUri.isBlank()) {
            throw new ServletException("❌ Missing google.redirectUri in web.xml");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String authorizationUrl = new GoogleAuthorizationCodeRequestUrl(
                clientId,
                redirectUri,
                Arrays.asList(
                        "openid",
                        "https://www.googleapis.com/auth/userinfo.email",
                        "https://www.googleapis.com/auth/userinfo.profile"
                )
        )
                .setAccessType("offline")   // Lấy refresh token nếu cần
                .setApprovalPrompt("force") // Luôn hỏi lại user
                .build();

        resp.sendRedirect(authorizationUrl);
    }
}
