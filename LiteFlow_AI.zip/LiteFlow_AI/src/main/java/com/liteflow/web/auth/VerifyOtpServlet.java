package com.liteflow.web.auth;

import com.liteflow.model.auth.User;
import com.liteflow.service.UserService;
import com.liteflow.util.Utils;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.Instant;
import java.util.UUID;

@WebServlet("/verify-otp")
public class VerifyOtpServlet extends HttpServlet {

    private final UserService userService = new UserService();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession(false);
        if (session == null) {
            req.setAttribute("error", "Session expired. Please sign up again.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        String email = (String) session.getAttribute("signupOtpEmail");
        String otpExpected = (String) session.getAttribute("signupOtp");
        Instant otpExpire = (Instant) session.getAttribute("signupOtpExpire");

        // Lấy OTP người dùng nhập
        String otpInput = String.join("",
                req.getParameter("otp1"),
                req.getParameter("otp2"),
                req.getParameter("otp3"),
                req.getParameter("otp4"),
                req.getParameter("otp5"),
                req.getParameter("otp6")
        );

        if (otpExpected == null || otpExpire == null || email == null) {
            req.setAttribute("error", "OTP session not found. Please request again.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Kiểm tra hết hạn
        if (Instant.now().isAfter(otpExpire)) {
            req.setAttribute("error", "OTP expired. Please request a new code.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // So khớp OTP
        if (!otpExpected.equals(otpInput)) {
            req.setAttribute("error", "Invalid OTP. Please try again.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Đăng ký user
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String confirmPassword = req.getParameter("confirmPassword");

        if (password == null || !password.equals(confirmPassword)) {
            req.setAttribute("error", "Passwords do not match");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        User u = new User();
        u.setUserID(UUID.randomUUID());
        u.setEmail(email);
        u.setDisplayName(username);
        u.setPasswordHash(Utils.hashPassword(password));
        u.setIsActive(true);

        boolean created = userService.addUser(u);

        if (created) {
            session.removeAttribute("signupOtp");
            session.removeAttribute("signupOtpEmail");
            session.removeAttribute("signupOtpExpire");

            req.setAttribute("msg", "Signup successful! Please login.");
            req.getRequestDispatcher("/auth/login.jsp").forward(req, resp);
        } else {
            req.setAttribute("error", "Failed to create account.");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
        }
    }
}
