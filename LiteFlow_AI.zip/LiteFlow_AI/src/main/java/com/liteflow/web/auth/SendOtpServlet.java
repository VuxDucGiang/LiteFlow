package com.liteflow.web.auth;

import com.liteflow.util.MailUtil; // class MailUtil đã tạo ở trên
import jakarta.mail.MessagingException;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.time.Instant;
import java.util.Random;

@WebServlet("/send-otp")
public class SendOtpServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String email = req.getParameter("email");
        if (email == null || email.isBlank()) {
            req.setAttribute("error", "Email is required to send OTP");
            req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
            return;
        }

        // Generate 6-digit OTP
        String otp = String.format("%06d", new Random().nextInt(999999));

        // Save OTP & expiry (5 minutes) in session
        HttpSession session = req.getSession(true);
        session.setAttribute("signupOtp", otp);
        session.setAttribute("signupOtpEmail", email);
        session.setAttribute("signupOtpExpire", Instant.now().plusSeconds(300)); // 5 mins

        try {
            // Gửi email OTP thật
            MailUtil.sendOtpMail(email, otp);
            req.setAttribute("msg", "✅ OTP has been sent to " + email);
        } catch (MessagingException e) {
            e.printStackTrace();
            req.setAttribute("error", "❌ Failed to send OTP email, please try again later.");
        }

        req.getRequestDispatcher("/auth/signup.jsp").forward(req, resp);
    }
}
