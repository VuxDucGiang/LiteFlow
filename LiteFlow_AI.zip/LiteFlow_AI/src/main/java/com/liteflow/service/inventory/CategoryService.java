/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.CategoryDAO;
import com.liteflow.model.inventory.Category;
import java.util.*;

public class CategoryService extends BaseService {

    private final CategoryDAO dao = new CategoryDAO();

    public Category create(Category c) {
        requireNonNull(c, "category");
        dao.insert(c);
        return c;
    }

    public boolean update(Category c) {
        requireNonNull(c, "category");
        return dao.update(c);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<Category> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<Category> listAll() {
        return dao.getAll();
    }

    public List<Category> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<Category> findByAttribute(String attr, Object val) {
        return dao.findByAttribute(attr, val);
    }

    // đặc thù DAO
    public List<Category> findChildren(String parentId) {
        checkId(parentId);
        return dao.findChildren(parentId);
    }
}
