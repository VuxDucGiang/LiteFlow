/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.SkuDAO;
import com.liteflow.model.inventory.SKU;
import java.util.*;

public class SkuService extends BaseService {

    private final SkuDAO dao = new SkuDAO();

    public SKU create(SKU s) {
        requireNonNull(s, "sku");
        dao.insert(s);
        return s;
    }

    public boolean update(SKU s) {
        requireNonNull(s, "sku");
        return dao.update(s);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<SKU> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<SKU> listAll() {
        return dao.getAll();
    }

    public List<SKU> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<SKU> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public Optional<SKU> findByCode(String skuCode) {
        requireNonNull(skuCode, "skuCode");
        return dao.findByCode(skuCode);
    }

    public Optional<SKU> findByBarcode(String barcode) {
        requireNonNull(barcode, "barcode");
        return dao.findByBarcode(barcode);
    }

    public List<SKU> findByProductId(String productId) {
        checkId(productId);
        return dao.findByProductId(productId);
    }
}
