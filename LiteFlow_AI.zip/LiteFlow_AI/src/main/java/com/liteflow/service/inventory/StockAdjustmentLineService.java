/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockAdjustmentLineDAO;
import com.liteflow.model.inventory.StockAdjustmentLine;
import java.util.*;

public class StockAdjustmentLineService extends BaseService {

    private final StockAdjustmentLineDAO dao = new StockAdjustmentLineDAO();

    public StockAdjustmentLine create(StockAdjustmentLine l) {
        requireNonNull(l, "adjustmentLine");
        dao.insert(l);
        return l;
    }

    public boolean update(StockAdjustmentLine l) {
        requireNonNull(l, "adjustmentLine");
        return dao.update(l);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockAdjustmentLine> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockAdjustmentLine> listAll() {
        return dao.getAll();
    }

    public List<StockAdjustmentLine> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockAdjustmentLine> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockAdjustmentLine> findByAdjustment(String adjustmentId) {
        checkId(adjustmentId);
        return dao.findByAdjustment(adjustmentId);
    }
}
