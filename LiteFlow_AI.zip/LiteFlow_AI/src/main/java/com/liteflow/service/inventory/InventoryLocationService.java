/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.InventoryLocationDAO;
import com.liteflow.model.inventory.InventoryLocation;
import java.util.*;

public class InventoryLocationService extends BaseService {

    private final InventoryLocationDAO dao = new InventoryLocationDAO();

    public InventoryLocation create(InventoryLocation l) {
        requireNonNull(l, "location");
        dao.insert(l);
        return l;
    }

    public boolean update(InventoryLocation l) {
        requireNonNull(l, "location");
        return dao.update(l);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<InventoryLocation> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<InventoryLocation> listAll() {
        return dao.getAll();
    }

    public List<InventoryLocation> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<InventoryLocation> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<InventoryLocation> findByBranch(String branch) {
        requireNonNull(branch, "branch");
        return dao.findByBranch(branch);
    }

    public List<InventoryLocation> findByBranchAndType(String branch, String type) {
        requireNonNull(branch, "branch");
        requireNonNull(type, "type");
        return dao.findByBranchAndType(branch, type);
    }
}
