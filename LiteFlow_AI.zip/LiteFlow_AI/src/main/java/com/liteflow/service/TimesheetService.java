package com.liteflow.service;

import com.liteflow.dao.GenericDAO;
import com.liteflow.model.hr.Timesheet;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

import java.util.Date;
import java.util.List;
import java.util.UUID;

public class TimesheetService extends GenericDAO<Timesheet, UUID> {

    public TimesheetService() {
        super(Timesheet.class);
    }

    /**
     * Nhân viên Check-In
     */
    public boolean checkIn(UUID employeeId, String method) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            Timesheet t = new Timesheet(UUID.randomUUID());
            t.setEmployeeID(em.getReference(com.liteflow.model.hr.Employee.class, employeeId));
            t.setCheckIn(new Date());
            t.setMethod(method);
            em.persist(t);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            e.printStackTrace();
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Nhân viên Check-Out (cập nhật dòng chưa checkout)
     */
    public boolean checkOut(UUID employeeId) {
        EntityManager em = emf.createEntityManager();
        EntityTransaction tx = em.getTransaction();
        try {
            tx.begin();
            Timesheet ts = em.createQuery(
                            "SELECT t FROM Timesheet t WHERE t.employeeID.employeeID = :empId AND t.checkOut IS NULL",
                            Timesheet.class)
                    .setParameter("empId", employeeId)
                    .setMaxResults(1)
                    .getSingleResult();

            ts.setCheckOut(new Date());
            em.merge(ts);
            tx.commit();
            return true;
        } catch (Exception e) {
            if (tx.isActive()) tx.rollback();
            System.err.println("❌ CheckOut Error: " + e.getMessage());
            return false;
        } finally {
            em.close();
        }
    }

    /**
     * Lấy toàn bộ timesheet theo nhân viên
     */
    public List<Timesheet> getByEmployee(UUID employeeId) {
        EntityManager em = emf.createEntityManager();
        try {
            return em.createQuery(
                            "SELECT t FROM Timesheet t WHERE t.employeeID.employeeID = :empId ORDER BY t.checkIn DESC",
                            Timesheet.class)
                    .setParameter("empId", employeeId)
                    .getResultList();
        } catch (Exception e) {
            System.err.println("❌ getByEmployee Error: " + e.getMessage());
            return List.of();
        } finally {
            em.close();
        }
    }
}
