/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockCountLineDAO;
import com.liteflow.model.inventory.StockCountLine;
import java.util.*;

public class StockCountLineService extends BaseService {

    private final StockCountLineDAO dao = new StockCountLineDAO();

    public StockCountLine create(StockCountLine l) {
        requireNonNull(l, "countLine");
        dao.insert(l);
        return l;
    }

    public boolean update(StockCountLine l) {
        requireNonNull(l, "countLine");
        return dao.update(l);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockCountLine> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockCountLine> listAll() {
        return dao.getAll();
    }

    public List<StockCountLine> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockCountLine> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockCountLine> findByCount(String countId) {
        checkId(countId);
        return dao.findByCount(countId);
    }
}
