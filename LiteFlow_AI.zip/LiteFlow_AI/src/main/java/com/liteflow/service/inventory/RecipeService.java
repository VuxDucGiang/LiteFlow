/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.RecipeDAO;
import com.liteflow.model.inventory.Recipe;
import java.util.*;

public class RecipeService extends BaseService {

    private final RecipeDAO dao = new RecipeDAO();

    public Recipe create(Recipe r) {
        requireNonNull(r, "recipe");
        dao.insert(r);
        return r;
    }

    public boolean update(Recipe r) {
        requireNonNull(r, "recipe");
        return dao.update(r);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<Recipe> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<Recipe> listAll() {
        return dao.getAll();
    }

    public List<Recipe> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<Recipe> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<Recipe> findByProduct(String productId) {
        checkId(productId);
        return dao.findByProduct(productId);
    }

    // DAO còn có findActiveByProduct(...), khi cần có thể wrap thêm:
    public Optional<Recipe> findActiveByProduct(String productId) {
        checkId(productId);
        return dao.findActiveByProduct(productId);
    }
}
