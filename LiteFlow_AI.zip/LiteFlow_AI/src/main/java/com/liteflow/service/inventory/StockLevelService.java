/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockLevelDAO;
import com.liteflow.model.inventory.StockLevel;
import com.liteflow.model.inventory.StockLevelPK;
import java.util.*;

public class StockLevelService extends BaseService {

    private final StockLevelDAO dao = new StockLevelDAO();

    public StockLevel create(StockLevel s) {
        requireNonNull(s, "stockLevel");
        dao.insert(s);
        return s;
    }

    public boolean update(StockLevel s) {
        requireNonNull(s, "stockLevel");
        return dao.update(s);
    }

    public boolean delete(String skuId, String locationId) {
        checkId(skuId);
        checkId(locationId);
        return dao.delete(new StockLevelPK(skuId, locationId));
    }

    public Optional<StockLevel> find(String skuId, String locationId) {
        checkId(skuId);
        checkId(locationId);
        return dao.findOne(skuId, locationId);
    }

    public List<StockLevel> listAll() {
        return dao.getAll();
    }

    public List<StockLevel> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockLevel> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockLevel> findByLocation(String locationId) {
        checkId(locationId);
        return dao.findByLocation(locationId);
    }
}
