/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service;

/**
 *
 * @author bovlnguyn
 */
public abstract class BaseService {

    protected void require(boolean condition, String message) {
        if (!condition) {
            throw new ServiceException(message);
        }
    }

    protected <T> T requireNonNull(T obj, String name) {
        if (obj == null) {
            throw new ServiceException(name + " must not be null");
        }
        return obj;
    }

    protected void checkId(String id) {
        if (id == null || id.isBlank()) {
            throw new ServiceException("ID must not be null/blank");
        }
    }
}
