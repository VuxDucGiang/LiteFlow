package com.liteflow.service;

import com.liteflow.util.Utils;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.liteflow.dao.GenericDAO;
import com.liteflow.model.auth.User;
import com.liteflow.model.auth.Role;
import com.liteflow.model.auth.Session;
import com.liteflow.model.auth.UserRole;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import java.util.Collection;

import java.util.List;
import java.util.UUID;

public class UserService {

    private final GenericDAO<User, UUID> userDao = new GenericDAO<>(User.class);
    private final GenericDAO<Role, UUID> roleDao = new GenericDAO<>(Role.class);
    private final GenericDAO<UserRole, UUID> userRoleDao = new GenericDAO<>(UserRole.class);
    private final GenericDAO<Session, UUID> sessionDao = new GenericDAO<>(Session.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    private static final EntityManagerFactory emf
            = Persistence.createEntityManagerFactory("LiteFlowPU"); // đồng bộ với persistence.xml

    private final AuditService audit = new AuditService();

    // ==============================
    // CRUD cơ bản
    // ==============================
    public List<User> getAllUsers() {
        return userDao.getAll();
    }

    public User getUserById(UUID id) {
        return userDao.findById(id);
    }

    public boolean addUser(User user) {
        return userDao.insert(user);
    }

    public boolean updateUser(User user) {
        return userDao.update(user);
    }

    public boolean deactivateUser(UUID id, String ip) {
        User user = userDao.findById(id);
        if (user != null) {
            user.setIsActive(false);
            boolean ok = userDao.update(user);
            if (ok) {
                audit.log(
                        user,
                        AuditService.AuditAction.LOCK_ACCOUNT,
                        AuditService.ObjectType.USER,
                        user.getUserID().toString(),
                        "User account locked",
                        ip
                );
            }
            return ok;
        }
        return false;
    }

    public boolean activateUser(UUID id, String ip) {
        User user = userDao.findById(id);
        if (user != null) {
            user.setIsActive(true);
            boolean ok = userDao.update(user);
            if (ok) {
                audit.log(
                        user,
                        AuditService.AuditAction.UNLOCK_ACCOUNT,
                        AuditService.ObjectType.USER,
                        user.getUserID().toString(),
                        "User account unlocked",
                        ip
                );
            }
            return ok;
        }
        return false;
    }

    // ==============================
    // Tìm kiếm
    // ==============================
    public User getUserByEmail(String email) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<User> query
                    = em.createQuery("SELECT u FROM User u WHERE u.email = :email", User.class);
            query.setParameter("email", email);
            List<User> users = query.getResultList();
            return users.isEmpty() ? null : users.get(0);
        } finally {
            em.close();
        }
    }

    // Alias cho AuthenticationFilter
    public User findByEmail(String email) {
        return getUserByEmail(email);
    }

    public User getUserByPhone(String phone) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<User> query
                    = em.createQuery("SELECT u FROM User u WHERE u.phone = :phone", User.class);
            query.setParameter("phone", phone);
            List<User> users = query.getResultList();
            return users.isEmpty() ? null : users.get(0);
        } finally {
            em.close();
        }
    }

    // ==============================
    // Bảo mật: đổi mật khẩu
    // ==============================
    public boolean changePassword(User user, String newPassword, String ip) {
        if (user == null || newPassword == null || newPassword.isEmpty()) {
            return false;
        }
        String hashedPassword = Utils.hashPassword(newPassword);
        user.setPasswordHash(hashedPassword);
        boolean ok = updateUser(user);
        if (ok) {
            audit.log(
                    user,
                    AuditService.AuditAction.CHANGE_PASSWORD,
                    AuditService.ObjectType.USER,
                    user.getUserID().toString(),
                    "User changed password",
                    ip
            );
        }
        return ok;
    }

    // ==============================
    // Quản lý Role
    // ==============================
    public void assignRole(UUID userId, UUID roleId) {
        UserRole ur = new UserRole();
        ur.setUserId(userId);
        ur.setRoleId(roleId);
        userRoleDao.insert(ur);
    }

    public List<Role> getUserRoles(UUID userId) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Role> query = em.createQuery(
                    "SELECT r FROM Role r, UserRole ur WHERE r.roleId = ur.roleId AND ur.userId = :uid",
                    Role.class
            );
            query.setParameter("uid", userId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    // ==============================
    // Quản lý Session (login)
    // ==============================
    public Session createSession(User user, String jwt, String device,
            String ip, java.time.LocalDateTime expiresAt) {
        Session session = new Session();
        session.setUserId(user.getUserID());
        session.setJwt(jwt);
        session.setDeviceInfo(device);
        session.setIpAddress(ip);
        session.setExpiresAt(expiresAt);
        session.setRevoked(false);
        sessionDao.insert(session);
        return session;
    }

    public boolean revokeSession(UUID sessionId) {
        Session session = sessionDao.findById(sessionId);
        if (session != null) {
            session.setRevoked(true);
            return sessionDao.update(session);
        }
        return false;
    }

    public List<Session> getUserSessions(UUID userId) {
        EntityManager em = emf.createEntityManager();
        try {
            TypedQuery<Session> query
                    = em.createQuery("SELECT s FROM Session s WHERE s.userId = :uid AND s.revoked = false", Session.class);
            query.setParameter("uid", userId);
            return query.getResultList();
        } finally {
            em.close();
        }
    }

    // ==============================
    // Quản lý Role (CRUD trực tiếp)
    // ==============================
    public List<Role> getAllRoles() {
        return roleDao.getAll();
    }

    public Role getRoleById(UUID roleId) {
        return roleDao.findById(roleId);
    }

    public boolean createRole(Role role) {
        if (role == null || role.getName() == null || role.getName().isEmpty()) {
            return false;
        }
        return roleDao.insert(role);
    }

    public boolean updateRole(Role role) {
        if (role == null || role.getRoleID() == null) {
            return false;
        }
        return roleDao.update(role);
    }

    public boolean deleteRole(UUID roleId) {
        Role role = roleDao.findById(roleId);
        if (role != null) {
            return roleDao.delete(roleId);
        }
        return false;
    }

//    /**
//     * Lấy role chính từ UserRoles
//     */
    public String getPrimaryRole(User user) {
        Collection<Role> roles = user.getRoles();
        if (roles != null && !roles.isEmpty()) {
            return roles.iterator().next().getName();
        }
        return null;
    }

//    /**
//     * Đọc một giá trị từ JSON meta
//     */
    public String getMetaValue(User user, String key) {
        if (user.getMeta() == null) {
            return null;
        }
        try {
            JsonNode node = MAPPER.readTree(user.getMeta());
            JsonNode v = node.get(key);
            return v != null ? v.asText() : null;
        } catch (JsonProcessingException e) {
            return null;
        }
    }

    public User findById(UUID id) {
        return userDao.findById(id);
    }

}
