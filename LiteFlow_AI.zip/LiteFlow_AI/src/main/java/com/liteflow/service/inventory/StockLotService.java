/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockLotDAO;
import com.liteflow.model.inventory.StockLot;
import java.util.*;

public class StockLotService extends BaseService {

    private final StockLotDAO dao = new StockLotDAO();

    public StockLot create(StockLot l) {
        requireNonNull(l, "lot");
        dao.insert(l);
        return l;
    }

    public boolean update(StockLot l) {
        requireNonNull(l, "lot");
        return dao.update(l);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockLot> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockLot> listAll() {
        return dao.getAll();
    }

    public List<StockLot> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockLot> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockLot> findLotsFEFO(String skuId, String locationId) {
        checkId(skuId);
        checkId(locationId);
        return dao.findLotsFEFO(skuId, locationId);
    }

    public List<StockLot> findExpiringBefore(String locationId, Date before) {
        checkId(locationId);
        requireNonNull(before, "before");
        return dao.findExpiringBefore(locationId, before);
    }
}
