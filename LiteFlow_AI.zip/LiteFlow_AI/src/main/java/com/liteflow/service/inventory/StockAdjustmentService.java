/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockAdjustmentDAO;
import com.liteflow.model.inventory.StockAdjustment;
import java.util.*;

public class StockAdjustmentService extends BaseService {

    private final StockAdjustmentDAO dao = new StockAdjustmentDAO();

    public StockAdjustment create(StockAdjustment a) {
        requireNonNull(a, "adjustment");
        dao.insert(a);
        return a;
    }

    public boolean update(StockAdjustment a) {
        requireNonNull(a, "adjustment");
        return dao.update(a);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockAdjustment> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockAdjustment> listAll() {
        return dao.getAll();
    }

    public List<StockAdjustment> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockAdjustment> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockAdjustment> findByLocationRange(String locationId, Date from, Date to) {
        requireNonNull(locationId, "locationId");
        requireNonNull(from, "from");
        requireNonNull(to, "to");
        return dao.findByLocationRange(locationId, from, to);
    }

    public List<StockAdjustment> findByReason(String locationId, String reason) {
        requireNonNull(locationId, "locationId");
        requireNonNull(reason, "reason");
        return dao.findByReason(locationId, reason);
    }
}
