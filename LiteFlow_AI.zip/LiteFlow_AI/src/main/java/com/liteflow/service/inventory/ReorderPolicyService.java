/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.ReorderPolicyDAO;
import com.liteflow.model.inventory.ReorderPolicy;
import java.util.*;

public class ReorderPolicyService extends BaseService {

    private final ReorderPolicyDAO dao = new ReorderPolicyDAO();

    public ReorderPolicy create(ReorderPolicy r) {
        requireNonNull(r, "reorderPolicy");
        dao.insert(r);
        return r;
    }

    public boolean update(ReorderPolicy r) {
        requireNonNull(r, "reorderPolicy");
        return dao.update(r);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<ReorderPolicy> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<ReorderPolicy> listAll() {
        return dao.getAll();
    }

    public List<ReorderPolicy> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<ReorderPolicy> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public Optional<ReorderPolicy> findOne(String skuId, String locationId) {
        return dao.findOne(skuId, locationId);
    }

    public List<ReorderPolicy> findByLocation(String locationId) {
        checkId(locationId);
        return dao.findByLocation(locationId);
    }
}
