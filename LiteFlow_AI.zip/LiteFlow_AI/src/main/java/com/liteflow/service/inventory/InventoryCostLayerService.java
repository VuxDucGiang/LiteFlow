/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.InventoryCostLayerDAO;
import com.liteflow.model.inventory.InventoryCostLayer;
import java.util.*;

public class InventoryCostLayerService extends BaseService {

    private final InventoryCostLayerDAO dao = new InventoryCostLayerDAO();

    public InventoryCostLayer create(InventoryCostLayer c) {
        requireNonNull(c, "costLayer");
        dao.insert(c);
        return c;
    }

    public boolean update(InventoryCostLayer c) {
        requireNonNull(c, "costLayer");
        return dao.update(c);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<InventoryCostLayer> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<InventoryCostLayer> listAll() {
        return dao.getAll();
    }

    public List<InventoryCostLayer> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<InventoryCostLayer> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<InventoryCostLayer> findFIFOAvailable(String skuId, String locationId) {
        checkId(skuId);
        checkId(locationId);
        return dao.findFIFOAvailable(skuId, locationId);
    }
}
