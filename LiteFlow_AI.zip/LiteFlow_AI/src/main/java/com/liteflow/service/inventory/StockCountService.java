/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockCountDAO;
import com.liteflow.model.inventory.StockCount;
import java.util.*;

public class StockCountService extends BaseService {

    private final StockCountDAO dao = new StockCountDAO();

    public StockCount create(StockCount c) {
        requireNonNull(c, "stockCount");
        dao.insert(c);
        return c;
    }

    public boolean update(StockCount c) {
        requireNonNull(c, "stockCount");
        return dao.update(c);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockCount> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockCount> listAll() {
        return dao.getAll();
    }

    public List<StockCount> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockCount> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockCount> findOpenByLocation(String locationId) {
        checkId(locationId);
        return dao.findOpenByLocation(locationId);
    }

    public List<StockCount> findByLocationRange(String locationId, Date from, Date to) {
        requireNonNull(locationId, "locationId");
        requireNonNull(from, "from");
        requireNonNull(to, "to");
        return dao.findByLocationRange(locationId, from, to);
    }
}
