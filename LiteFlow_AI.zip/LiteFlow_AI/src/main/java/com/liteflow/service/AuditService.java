package com.liteflow.service;

import com.liteflow.model.auth.AuditLog;
import com.liteflow.model.auth.User;
import com.liteflow.dao.GenericDAO;

import java.util.Date;
import java.util.UUID;

/**
 * AuditService: Ghi nhật ký hành động (Audit Logs) của người dùng
 * - Dùng cho login/logout, thay đổi dữ liệu quan trọng, v.v.
 * - Dùng GenericDAO để lưu dữ liệu.
 */
public class AuditService {

    private final GenericDAO<AuditLog, String> auditDao = new GenericDAO<>(AuditLog.class);

    /** Enum chuẩn hóa loại hành động */
    public enum AuditAction {
        LOGIN_SUCCESS,
        LOGIN_FAIL,
        LOGOUT,
        CREATE,
        UPDATE,
        DELETE,
        CHANGE_PASSWORD,
        LOCK_ACCOUNT,
        UNLOCK_ACCOUNT,
        ACCESS_DENIED, LOGIN
    }

    /** Enum chuẩn hóa loại đối tượng bị tác động */
    public enum ObjectType {
        USER,
        ORDER,
        PRODUCT,
        INVENTORY,
        PAYROLL,
        OTHER
    }

    /**
     * Ghi một bản ghi Audit Log
     *
     * @param user       User thực hiện hành động
     * @param action     Hành động (enum AuditAction)
     * @param objectType Loại đối tượng (enum ObjectType)
     * @param objectId   ID của đối tượng (String UUID)
     * @param details    Chi tiết thêm (JSON/string)
     * @param ip         Địa chỉ IP
     */
    public void log(User user,
                    AuditAction action,
                    ObjectType objectType,
                    String objectId,
                    String details,
                    String ip) {
        try {
            AuditLog log = new AuditLog(UUID.randomUUID().toString());
            log.setUserID(user);
            log.setAction(action.name());          // Lưu action dạng string
            log.setObjectType(objectType.name()); // Lưu object type dạng string
            log.setObjectID(objectId);
            log.setDetails(details);
            log.setIPAddress(ip);
            log.setCreatedAt(new Date());

            auditDao.insert(log);

        } catch (Exception e) {
            System.err.println("❌ Lỗi khi ghi AuditLog: " + e.getMessage());
        }
    }
}
