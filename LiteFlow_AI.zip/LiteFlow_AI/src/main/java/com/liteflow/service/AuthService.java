package com.liteflow.service;

import com.liteflow.dao.GenericDAO;
import com.liteflow.model.auth.User;
import org.mindrot.jbcrypt.BCrypt;

import java.util.Optional;
import java.util.UUID;

/**
 * AuthService: Dịch vụ xác thực người dùng.
 * 
 * Chức năng:
 *  - Tìm user theo email hoặc số điện thoại
 *  - Kiểm tra mật khẩu với BCrypt
 *  - Kiểm tra trạng thái tài khoản (active)
 *  - Kiểm tra yêu cầu 2FA
 *  - Ghi log thử đăng nhập
 */
public class AuthService {

    private final GenericDAO<User, UUID> userDao = new GenericDAO<>(User.class);
    private final AuditService audit = new AuditService();

    /**
     * Tìm người dùng theo email hoặc số điện thoại.
     *
     * @param emailOrPhone email hoặc số điện thoại
     * @return Optional<User>
     */
    public Optional<User> findByEmailOrPhone(String emailOrPhone) {
        if (emailOrPhone == null || emailOrPhone.isBlank()) {
            return Optional.empty();
        }

        User u = userDao.findSingleByField("email", emailOrPhone);
        if (u != null) {
            return Optional.of(u);
        }

        u = userDao.findSingleByField("phone", emailOrPhone);
        return Optional.ofNullable(u);
    }

    /**
     * Kiểm tra mật khẩu có khớp với user không.
     *
     * @param user       User cần kiểm tra
     * @param rawPassword mật khẩu plaintext
     * @return true nếu hợp lệ, false nếu sai hoặc user không active
     */
    public boolean checkPassword(User user, String rawPassword) {
        return user != null
                && user.isActiveSafe()
                && rawPassword != null
                && BCrypt.checkpw(rawPassword, user.getPasswordHash());
    }

    /**
     * Kiểm tra user có yêu cầu xác thực hai lớp (2FA TOTP) không.
     *
     * @param user User
     * @return true nếu cần 2FA
     */
    public boolean is2faRequired(User user) {
        return user != null
                && user.getTwoFactorSecret() != null
                && !user.getTwoFactorSecret().isBlank();
    }

    /**
     * Ghi log một lần thử đăng nhập.
     *
     * @param user    User (có thể null)
     * @param success true nếu đăng nhập thành công
     * @param ip      địa chỉ IP client
     */
    public void logLoginAttempt(User user, boolean success, String ip) {
        String userId = (user != null ? user.getUserID().toString() : "UNKNOWN");

        audit.log(user,
                AuditService.AuditAction.LOGIN,
                AuditService.ObjectType.USER,
                userId,
                success ? "Login success" : "Login failed",
                ip);
    }
}
