package com.liteflow.service;

import com.liteflow.model.auth.User;
import com.liteflow.security.JwtUtil;
import com.liteflow.security.TotpUtil;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.JwtException;

import java.time.Duration;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * LoginService chứa logic login:
 *  - Xác thực user (email/phone, password, 2FA)
 *  - Phát hành JWT (dùng JwtUtil)
 *  - Audit log
 *  - Không còn phụ thuộc Redis
 */
public class LoginService {

    private final AuthService auth = new AuthService();
    private final AuditService audit = new AuditService();
    private final UserService userService = new UserService();

    // TTL cho token (30 phút)
    private static final Duration SESSION_TTL = Duration.ofMinutes(30);

//    /**
//     * Xác thực login và trả về JWT nếu thành công, null nếu thất bại.
//     */
    public String login(String id, String password, String totp, String ip) {
        Optional<User> optUser = auth.findByEmailOrPhone(id);

        if (optUser.isEmpty() || !optUser.get().isActiveSafe()) {
            audit.log(null,
                    AuditService.AuditAction.LOGIN_FAIL,
                    AuditService.ObjectType.USER,
                    null,
                    "User not found or inactive",
                    ip);
            return null;
        }

        User user = optUser.get();

        // Kiểm tra password
        if (!auth.checkPassword(user, password)) {
            audit.log(user,
                    AuditService.AuditAction.LOGIN_FAIL,
                    AuditService.ObjectType.USER,
                    user.getUserID().toString(),
                    "Invalid password",
                    ip);
            return null;
        }

        // Kiểm tra 2FA nếu có bật
        if (auth.is2faRequired(user)) {
            if (totp == null || !TotpUtil.verifyCode(user.getTwoFactorSecret(), totp)) {
                audit.log(user,
                        AuditService.AuditAction.LOGIN_FAIL,
                        AuditService.ObjectType.USER,
                        user.getUserID().toString(),
                        "Invalid or missing TOTP code",
                        ip);
                return null;
            }
        }

        // Payload thêm vào JWT
        Map<String, Object> claims = new HashMap<>();
        claims.put("email", user.getEmail());
        claims.put("displayName", user.getDisplayName());

        // Lấy role từ service (ưu tiên UserRoles, fallback Meta)
        String role = userService.getPrimaryRole(user);
        if (role == null) {
            role = userService.getMetaValue(user, "role");
        }
        claims.put("role", role);

        // JTI (ID của token, chỉ để track trong payload, không còn lưu Redis)
        String jti = UUID.randomUUID().toString();
        claims.put("jti", jti);

        // Phát hành JWT
        String token = JwtUtil.createToken(
                user.getUserID().toString(),
                SESSION_TTL.toSeconds(),
                claims
        );

        // Audit log thành công
        audit.log(user,
                AuditService.AuditAction.LOGIN_SUCCESS,
                AuditService.ObjectType.USER,
                user.getUserID().toString(),
                "Login success",
                ip);

        return token;
    }
//
//    /**
//     * Kiểm tra JWT có hợp lệ (chỉ chữ ký & expiration).
//     */
    public boolean validateToken(String token) {
        try {
            Jws<Claims> parsed = JwtUtil.parse(token);
            return parsed.getBody().getExpiration().after(new java.util.Date());
        } catch (JwtException e) {
            return false;
        }
    }

//    /**
//     * Logout: ở bản không dùng Redis thì chỉ cần client xoá cookie + session.
//     */
    public void logout(String token) {
        // Không cần revoke server-side vì không có Redis
        // Có thể chỉ parse để log
        try {
            Jws<Claims> parsed = JwtUtil.parse(token);
            System.out.println("Logout user=" + parsed.getBody().getSubject());
        } catch (JwtException e) {
            System.err.println("Invalid token on logout: " + e.getMessage());
        }
    }
}
