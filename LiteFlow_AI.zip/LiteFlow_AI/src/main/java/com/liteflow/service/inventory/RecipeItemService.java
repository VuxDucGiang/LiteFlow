/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.RecipeItemDAO;
import com.liteflow.model.inventory.RecipeItem;
import java.util.*;

public class RecipeItemService extends BaseService {

    private final RecipeItemDAO dao = new RecipeItemDAO();

    public RecipeItem create(RecipeItem i) {
        requireNonNull(i, "recipeItem");
        dao.insert(i);
        return i;
    }

    public boolean update(RecipeItem i) {
        requireNonNull(i, "recipeItem");
        return dao.update(i);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<RecipeItem> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<RecipeItem> listAll() {
        return dao.getAll();
    }

    public List<RecipeItem> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<RecipeItem> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<RecipeItem> findByRecipe(String recipeId) {
        checkId(recipeId);
        return dao.findByRecipe(recipeId);
    }
}
