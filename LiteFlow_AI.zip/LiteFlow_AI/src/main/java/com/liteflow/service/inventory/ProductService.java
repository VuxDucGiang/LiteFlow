/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.ProductDAO;
import com.liteflow.model.inventory.Product;
import java.util.*;

public class ProductService extends BaseService {

    private final ProductDAO dao = new ProductDAO();

    public Product create(Product p) {
        requireNonNull(p, "product");
        dao.insert(p);
        return p;
    }

    public boolean update(Product p) {
        requireNonNull(p, "product");
        return dao.update(p);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<Product> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<Product> listAll() {
        return dao.getAll();
    }

    public List<Product> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<Product> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public Optional<Product> findByProductCode(String code) {
        requireNonNull(code, "productCode");
        return dao.findByProductCode(code);
    }

    public List<Product> searchByNameLike(String q, int limit) {
        return dao.searchByNameLike(q, limit);
    }
}
