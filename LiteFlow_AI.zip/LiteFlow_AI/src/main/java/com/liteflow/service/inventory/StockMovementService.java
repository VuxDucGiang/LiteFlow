/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.liteflow.service.inventory;

/**
 *
 * @author bovlnguyn
 */
import com.liteflow.service.*;
import com.liteflow.dao.inventory.StockMovementDAO;
import com.liteflow.model.inventory.StockMovement;
import java.util.*;

public class StockMovementService extends BaseService {

    private final StockMovementDAO dao = new StockMovementDAO();

    public StockMovement create(StockMovement m) {
        requireNonNull(m, "movement");
        dao.insert(m);
        return m;
    }

    public boolean update(StockMovement m) {
        requireNonNull(m, "movement");
        return dao.update(m);
    }

    public boolean delete(String id) {
        checkId(id);
        return dao.delete(id);
    }

    public Optional<StockMovement> find(String id) {
        checkId(id);
        return Optional.ofNullable(dao.findById(id));
    }

    public List<StockMovement> listAll() {
        return dao.getAll();
    }

    public List<StockMovement> list(int offset, int limit) {
        return dao.listWithOffset(offset, limit);
    }

    public List<StockMovement> findByAttribute(String a, Object v) {
        return dao.findByAttribute(a, v);
    }

    // đặc thù DAO
    public List<StockMovement> findByRef(String refType, String refId) {
        requireNonNull(refType, "refType");
        requireNonNull(refId, "refId");
        return dao.findByRef(refType, refId);
    }

    public List<StockMovement> findBySkuInRange(String skuId, Date from, Date to, int page, int size) {
        checkId(skuId);
        requireNonNull(from, "from");
        requireNonNull(to, "to");
        return dao.findBySkuInRange(skuId, from, to, page, size);
    }

    public long countBySkuInRange(String skuId, Date from, Date to) {
        checkId(skuId);
        requireNonNull(from, "from");
        requireNonNull(to, "to");
        return dao.countBySkuInRange(skuId, from, to);
    }
}
